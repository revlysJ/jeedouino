<?php
/* This file is part of Jeedouino, plugin of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom and the jeedouino plugin are distributed in the hope that they will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */

$this_file = "JeedouinoCron.php";
include 'jeedouinoExt.inc.php';	

if (isset($_SERVER['REQUEST_URI']))	$this_url = $_SERVER['REQUEST_URI'];
else $this_url = $_SERVER['PHP_SELF'];

$this_url = str_replace($this_file ,'' , $this_url );
$p0 = strpos($this_url, '?');
if ($p0 !== false) $this_url = substr($this_url, 0 , $p0); // supprime les params après ? dans l'url reçue.

if (isset($_SERVER['SERVER_PORT']))	$this_port = $_SERVER['SERVER_PORT'];
else $this_port = 80;

$datetimeStart = time() + 300; // 5 minutes
$datetime = date('YmdHi');
$jeedouinoPATH = realpath(dirname(__FILE__));
$filename = $jeedouinoPATH . '/' . $datetime . '.jee';		
$hier = $jeedouinoPATH . '/hier.jee';	
if (!file_exists($filename)) 
{
	if (file_exists($hier)) 
	{
		$temp_file = file_get_contents($hier);
		if (file_exists($temp_file)) 
		{
			$datetimeOld = file_get_contents($temp_file);			
			// On vérifie que ca ne fait pas moins de 5 minutes
			if ($datetimeOld > time()) $datetimeStart = $datetimeOld;
			unlink($temp_file);
		}
	}
	file_put_contents($hier, $filename);	
	file_put_contents($filename, $datetimeStart);	
	$filename = $jeedouinoPATH . '/jeedouinoPrm.prm';		
	if (file_exists($filename)) 
	{
		$file = file_get_contents($filename);	// Liste des démons présents sur ce rpi

		// On vérifie si les démons sont déja actifs
		$daemons = json_decode($file, true);
		foreach($daemons as $ids => $Dname)
		{
			if (StatusDemonCMD($ids, $Dname['DemonName'])) $cfg = false; 	// si oui pas la peine de redemander un démarrage de ceux-ci.
		}

		// On vérifie que ca ne fait pas moins de 5 minutes
		if ($datetimeOld > time()) $cfg = false;

		if ($cfg !== false) 
		{
			$_CFG = json_decode(GetJeedomCFG(), true);
			$UsbMapping = getUsbMapping();
			if ($_CFG['IP'] != '') 
			{
				$dstart = array_keys($daemons);	
				$param = 'ip=' . GetJeedouinoIP();
				$param .= '&port=' . $this_port;
				$param .= '&path=' . urlencode($this_url);
				$param .= '&usbMapping=' . urlencode(json_encode($UsbMapping));
				$param .= '&Dstart=' . json_encode($dstart);
				$url = 'http://' . $_CFG['IP'] .  ':' . $_CFG['Port'] . $_CFG['Cpl'] .  '/plugins/jeedouino/core/php/CallbackExt.php?' . $param;
				$reponse = file_get_contents($url);
				Jlog( 'debug', 'Call ' . $_CFG['IP'] . ':' . $_CFG['Port'] . ' - ' . $reponse);
				Jlog( 'debug', date('Y-m-d H:i:s').' Demande de démarrage des démons effectuée : ' . json_encode($dstart));
			}
		}		
	}
	else Jlog( 'debug', $filename . ' introuvable! Demande de démarrage des démons impossible.');
}
else Jlog( 'debug', 'BOOT - Demande de démarrage des démons déja effectuée.');
?>