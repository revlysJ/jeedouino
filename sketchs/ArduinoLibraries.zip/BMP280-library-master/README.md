# BMP280-library
This library now handles both BMP280 and BME280 devices. 
See my project on Instructables for use details. 
