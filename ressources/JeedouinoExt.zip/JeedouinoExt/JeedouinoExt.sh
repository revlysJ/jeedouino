##
# JeedouinoExt Install déportée sur RaspberryPi sans Jeedom
# v0.3 alpha
##

echo "================================="
echo "== JeedouinoExt v0.3 alpha"
echo "== Debut de l'installation ..."
echo "================================="

echo "== Desactivation de Nginx si present."
sudo /etc/init.d/nginx stop 
sudo systemctl disable nginx
echo "== Desactivation de osmc/kodi si present."
sudo systemctl stop mediacenter

echo "== Mises a jour du systeme en cours ..."
echo "/!\ Peut etre long suivant votre systeme."
echo "================================="
# Mettre a jour le systeme
sudo apt-get -y update
sudo apt-get -y upgrade
sudo apt-get -y dist-upgrade
cd /tmp

echo "== Installation des dependances Python ..."
echo "================================="
# installation des dependances Python
sudo apt-get -y install build-essential python{,3}-pip python{,3}-setuptools python{,3}-serial python{,3}-dev python{,3}-openssl git
sudo pip install wheel
sudo pip3 install wheel

echo "== Installation de la lib Adafruit_Python_DHT  ..."
echo "================================="
git clone https://github.com/adafruit/Adafruit_Python_DHT.git
cd Adafruit_Python_DHT
sudo python setup.py install
sudo python3 setup.py install
cd ..

echo "== Installation de la lib Adafruit_Python_BMP085/180  ..."
echo "================================="
git clone https://github.com/adafruit/Adafruit_Python_BMP.git
cd Adafruit_Python_BMP
sudo python setup.py install
sudo python3 setup.py install
cd ..

echo "== Installation de la lib ABElectronics_Python_Libraries  ..."
echo "================================="
git clone https://github.com/abelectronicsuk/ABElectronics_Python_Libraries.git
cd ABElectronics_Python_Libraries
sudo python setup.py install
sudo python3 setup.py install
cd ..

echo "== Installation de la lib danjperron/BitBangingDS18B20  ..."
echo "================================="
git clone https://github.com/danjperron/BitBangingDS18B20.git
cd BitBangingDS18B20/python
sudo python setup.py install
sudo python3 setup.py install
cd ../..

echo "== Installation de la lib Adafruit_Python_BME280  ..."
echo "================================="
pip3 install adafruit-circuitpython-lis3dh
sudo pip3 install adafruit-circuitpython-bme280
sudo pip3 install adafruit-circuitpython-bmp280

echo "== Installation de la lib Adafruit_Python_BME680  ..."
echo "================================="
sudo pip3 install adafruit-circuitpython-bme680

echo "== Installation de Apache pour Raspbian ..."
echo "================================="
sudo apt-get -y install apache2 apache2-utils libexpat1 ssl-cert

echo "== Installation de PHP pour Raspbian ..."
echo "================================="
sudo apt-get -y install php libapache2-mod-php php-json php-mysql php-curl php-ssh2 php-zip

echo "== Installation de crontab  ..."
echo "================================="
# Installer le crontab
sudo apt-get install cron

echo "== Copie des fichiers JeedouinoExt et mise en place des droits  ..."
echo "================================="
sudo rm -Rf /var/www/html/JeedouinoExt*
sudo chmod -R 775 /var/www/
sudo mkdir -p /var/www/html/log
sudo mkdir -p /var/www/html/JeedouinoExt
sudo cp -r /tmp/JeedouinoExt/*  /var/www/html/JeedouinoExt/
sudo chown -R www-data:www-data /var/www/html
sudo chmod -R 775 /var/www/html
sudo rm -Rf /tmp/JeedouinoExt*

echo "== Creation du cronjob ..."
echo "================================="
# Creation du cronjob pour les relances auto apres redemarrage
JeedouinoCron="`crontab -l | grep -e 'JeedouinoCron.php'`"
if [ -z "${JeedouinoCron}" ] ; then
	croncmd="su --shell=/bin/bash - www-data -c '/usr/bin/php /var/www/html/JeedouinoExt/JeedouinoCron.php' >> /dev/null 2>&1"
	cronjob="* * * * * $croncmd"
	( crontab -l | grep -v "$croncmd" ; echo "$cronjob" ) | crontab -
fi	
crontab -l
echo "www-data ALL=(ALL) NOPASSWD: ALL" | (EDITOR="tee -a" visudo)

echo "== Creation de fichiers HTML/PHP pour tests ..."
echo "================================="
# ajouter un fichier « index.php » pour vérifier que PHP fonctionne
echo "<?php header('location: JeedouinoExt/JeedouinoExt.php'); ?>" > /var/www/html/index.php
echo "<?php header('location: JeedouinoExt.php'); ?>" > /var/www/html/JeedouinoExt/index.php
# ajouter un fichier « index.html » pour vérifier que Apache fonctionne (Si Erreur 403 forbidden)
echo 'HTML OK - Apache marche !<br><br>Essayez <a href="/JeedouinoExt/">JeedouinoExt</a>' > /var/www/html/index.html
echo 'HTML OK <br><br>Essayez en php <a href="index.php">JeedouinoExt.php</a>' > /var/www/html/JeedouinoExt/index.html

echo "== Redemarrage de Apache ..."
echo "================================="
sudo /etc/init.d/apache2 restart

echo "================================="
echo "== Fin de l'installation ..."
echo "================================="