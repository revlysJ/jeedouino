##
# JeedouinoExt Install déportée sur RaspberryPi sans Jeedom
# v0.3 alpha
##

echo "==================================================================="
echo "== Copie des fichiers JeedouinoExt et mise en place des droits  ..."
echo "==================================================================="
sudo rm -Rf /var/www/html/JeedouinoExt*
sudo chmod -R 775 /var/www/
sudo mkdir -p /var/www/html/log
sudo mkdir -p /var/www/html/JeedouinoExt
sudo cp -r /tmp/JeedouinoExt/*  /var/www/html/JeedouinoExt/
sudo chown -R www-data:www-data /var/www/html
sudo chmod -R 775 /var/www/html
sudo rm -Rf /tmp/JeedouinoExt*
echo "==================================================================="
