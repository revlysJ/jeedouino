<?php
/* This file is part of Jeedouino, plugin of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom and the jeedouino plugin are distributed in the hope that they will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */
 
 include 'jeedouinoExt.inc.php';	
 

	// POST_log();
	// GET_log() ;

try {
	
    // Actions pour la gestion du démon piFace / Jeedouino
 	if (init('action') == 'StartPiFaceDemon') 
    {
        StartDemonCMD(init('boardid'),'PiFace');		
		success();
	}   
  	if (init('action') == 'ReStartPiFaceDemon') 
    {
        ReStartDemonCMD(init('boardid'),'PiFace');		
		success();
	}   
 	if (init('action') == 'StopPiFaceDemon') 
    {
        StopDemonCMD(init('boardid'),'PiFace');		
		success();
	} 
 	if (init('action') == 'DeletePiFaceDemon')
    {
		EraseDemonFileCMD(init('boardid'),'PiFace');
		success();
	}
    // Actions pour la gestion du démon piGPIO / Jeedouino
 	if (init('action') == 'StartPiGpioDemon') 
    {
        StartDemonCMD(init('boardid'),'PiGpio');		
		success();
	}   
  	if (init('action') == 'ReStartPiGpioDemon') 
    {
        ReStartDemonCMD(init('boardid'),'PiGpio');		
		success();
	}   
 	if (init('action') == 'StopPiGpioDemon') 
    {
        StopDemonCMD(init('boardid'),'PiGpio');
		success();
	}
 	if (init('action') == 'DeletePiGpioDemon')
    {
		EraseDemonFileCMD(init('boardid'),'PiGpio');
		success();
	}
    // Actions pour la gestion du démon PiPlus / Jeedouino
 	if (init('action') == 'StartPiPlusDemon') 
    {
        StartDemonCMD(init('boardid'),'PiPlus');		
		success();
	}   
  	if (init('action') == 'ReStartPiPlusDemon') 
    {
        ReStartDemonCMD(init('boardid'),'PiPlus');	
		success();
	}   
 	if (init('action') == 'StopPiPlusDemon') 
    {
        StopDemonCMD(init('boardid'),'PiPlus');		
		success();
	}
 	if (init('action') == 'DeletePiPlusDemon')
    {
		EraseDemonFileCMD(init('boardid'),'PiPlus');
		success();
	}
    // Actions pour la gestion du démon ArduinoUsb / Jeedouino
 	if (init('action') == 'StartUSBDemon') 
    {
        StartDemonCMD(init('boardid'),'USB');		
		success();
	}   
  	if (init('action') == 'ReStartUSBDemon') 
    {
        ReStartDemonCMD(init('boardid'),'USB');		
		success();
	}   
 	if (init('action') == 'StopUSBDemon') 
    {
        StopDemonCMD(init('boardid'),'USB');		
		success();
	}
 	if (init('action') == 'DeleteUSBDemon')
    {
		EraseDemonFileCMD(init('boardid'),'USB');
		success();
	}
	// Actions pour les logs
 	if (init('action') == 'getLog')
    {
		success(getLog(init('logfile')));
	}
 	if (init('action') == 'DeleteLog')
    {
		EraseLogFile(init('logfile'));
		success();
	}
    // Installation des dépendances
  	if (init('action') == 'installUpdate') 
    {
		Jlog( 'debug', 'sudo apt-get -y update demandé...');
        exec('sudo apt-get -y update >> JeedouinoExt.log 2>&1 &');
		Jlog( 'debug', 'sudo apt-get -y upgrade demandé...');
        exec('sudo apt-get -y upgrade >> JeedouinoExt.log 2>&1 &');
		Jlog( 'debug', 'sudo apt-get -y dist-upgrade demandé...');
        exec('sudo apt-get -y dist-upgrade >> JeedouinoExt.log 2>&1 &');	
		success();
	}   
  	if (init('action') == 'FilesUpdate') 
    {
        exec('sudo /bin/bash JeedouinoExt.maj >> JeedouinoExt.log 2>&1 &');		
		success();
	} 	
  	if (init('action') == 'installPython') 
    {
        exec('sudo /bin/bash Jeedouino.sh >> JeedouinoExt.log 2>&1 &');		
		success();
	}   	
  	if (init('action') == 'installGPIO')
    {
		Jlog( 'debug', 'sudo pip install RPi.GPIO demandé...');
        exec('sudo pip install RPi.GPIO >> JeedouinoExt.log 2>&1 &');		
		success();
	}   
 	if (init('action') == 'installPIFACE') 
    {
        //exec('sudo `which apt-get` -y install python-pifacedigitalio >> JeedouinoPiFace.log 2>&1 &');
		Jlog( 'debug', 'sudo pip install pifacecommon pifacedigitalio demandé...');
		exec('sudo pip3 install pifacecommon pifacedigitalio >> JeedouinoExt.log 2>&1 &');
		exec('sudo pip install pifacecommon pifacedigitalio >> JeedouinoExt.log 2>&1 &');

		// enable spi
		Jlog( 'debug', 'sudo enable spi (dtparam=spi=on  /boot/config.txt) demandé... Un reboot sera nécéssaire !');
		exec('sudo echo dtparam=spi=on | sudo tee -a /boot/config.txt');

		success();
	}      
 	if (init('action') == 'installPiPlus') 
    {
		Jlog( 'debug', 'sudo apt-get -y install i2c-tools libi2c-dev python-smbus python3-smbus demandé...');
        exec('sudo apt-get -y install i2c-tools libi2c-dev python-smbus python3-smbus >> JeedouinoExt.log 2>&1 &');
		// enable i2c
		Jlog( 'debug', '(dtparam=i2c_arm=on & dtparam=i2c1=on /boot/config.txt) demandé... Un reboot sera nécéssaire !');
		exec('sudo echo dtparam=i2c_arm=on | sudo tee -a /boot/config.txt');
		exec('sudo echo dtparam=i2c1=on | sudo tee -a /boot/config.txt');
		Jlog( 'debug', '(i2c-dev & i2c-bcm2708 /etc/modules) demandé... Un reboot sera nécéssaire !');
		exec('sudo echo i2c-dev | sudo tee -a /etc/modules');
		exec('sudo echo i2c-bcm2708 | sudo tee -a /etc/modules');
		success();
	} 
    // redemarrage / extinction
  	if (init('action') == 'installReboot') 
    {
		Jlog( 'debug', 'sudo /sbin/reboot demandé...');
        exec('sudo /sbin/reboot >> JeedouinoExt.log 2>&1 &');		
		success();
	}    	
  	if (init('action') == 'installShutdown') 
    {
		Jlog( 'debug', 'sudo /sbin/shutdown >> JeedouinoExt.log 2>&1 & demandé...');
        exec('sudo /sbin/shutdown >> JeedouinoExt.log 2>&1 &');		
		success();
	}	
    // action qui permet d'effectuer la sauvegarde des données en asynchrone
    throw new Exception('Aucune methode correspondante à : '. __FILE__ . ' >>> '.init('action'));
    /*     * *********Catch exeption*************** */
} catch (Exception $e) {
    //ajax::error(displayExeption($e), $e->getCode());
	file_put_contents('ajaxError.txt',$e." ".$e->getCode());
}
?>