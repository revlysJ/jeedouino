##
# JeedouinoExt Install déportée sur RaspberryPi sans Jeedom
# v0.3 alpha
##

echo "================================="
echo "== JeedouinoExt v0.3 alpha"
echo "== Debut de l'installation ..."
echo "================================="

echo "== Copie des fichiers JeedouinoExt et mise en place des droits  ..."
echo "================================="
sudo chmod -R 775 /var/www/
sudo mkdir -p /var/www/html/JeedouinoExt
sudo cp -r /tmp/JeedouinoExt/*  /var/www/html/JeedouinoExt/
sudo chown -R www-data:www-data /var/www/html
sudo chmod -R 775 /var/www/html
sudo rm -Rf /tmp/JeedouinoExt*

VENV_DIR=/venv

echo "== Installation des dependances Python ..."
echo "================================="
# installation des dependances Python
sudo apt-get -y install build-essential python3 python3-pip python3-dev python3-venv python3-setuptools python3-openssl git
sudo python3 -m venv --upgrade-deps ${VENV_DIR}
sudo ${VENV_DIR}/bin/python3 -m pip install --upgrade setuptools pip wheel
sudo apt-get -y install python3-serial
sudo ${VENV_DIR}/bin/python3 -m pip install pyserial

echo "== Installation RPi.GPIO  ..."
echo "================================="
sudo ${VENV_DIR}/bin/python3 -m pip install RPi.GPIO

echo "== Installation de la lib Adafruit_Python_DHT  ..."
echo "================================="
rm -Rf Adafruit_Python_DHT
git clone https://github.com/adafruit/Adafruit_Python_DHT.git
# workaround faked rpi version -
echo -e "\nHardware   : BCM2709" >> /etc/cpuinfo
if [ -e /etc/cpuinfo ] ; then
	mount --bind /etc/cpuinfo /proc/cpuinfo
fi
sudo ${VENV_DIR}/bin/python3 -m pip install /Adafruit_Python_DHT

echo "== Installation de la lib Adafruit_Python_BMP085/180  ..."
echo "================================="
rm -Rf Adafruit_Python_BMP
git clone https://github.com/adafruit/Adafruit_Python_BMP.git
sudo ${VENV_DIR}/bin/python3 -m pip install /Adafruit_Python_BMP

echo "== Installation de la lib ABElectronics_Python_Libraries  ..."
echo "================================="
rm -Rf ABElectronics_Python_Libraries
git clone https://github.com/abelectronicsuk/ABElectronics_Python_Libraries.git
sudo ${VENV_DIR}/bin/python3 -m pip install /ABElectronics_Python_Libraries

echo "== Installation de la lib danjperron/BitBangingDS18B20  ..."
echo "================================="
rm -Rf BitBangingDS18B20
git clone https://github.com/danjperron/BitBangingDS18B20.git
sudo ${VENV_DIR}/bin/python3 -m pip install /BitBangingDS18B20/python

echo "== Installation de la lib Adafruit_Python_BME280  ..."
echo "================================="
sudo ${VENV_DIR}/bin/python3 -m pip install adafruit-circuitpython-lis3dh
sudo ${VENV_DIR}/bin/python3 -m pip install adafruit-circuitpython-bme280
sudo ${VENV_DIR}/bin/python3 -m pip install adafruit-circuitpython-bmp280

echo "== Installation de la lib Adafruit_Python_BME680  ..."
echo "================================="
sudo ${VENV_DIR}/bin/python3 -m pip install adafruit-circuitpython-bme680

echo "================================="
echo "== Fin de l'installation ..."
echo "================================="
