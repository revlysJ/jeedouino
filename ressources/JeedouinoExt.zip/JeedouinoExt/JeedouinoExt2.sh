##
# JeedouinoExt Install déportée sur RaspberryPi sans Jeedom
# v0.3 alpha
##

echo "================================="
echo "== JeedouinoExt v0.3 alpha"
echo "== Debut de l'installation ..."
echo "================================="

echo "== Copie des fichiers JeedouinoExt et mise en place des droits  ..."
echo "================================="
sudo chmod -R 775 /var/www/
sudo mkdir -p /var/www/html/JeedouinoExt
sudo cp -r /tmp/JeedouinoExt/*  /var/www/html/JeedouinoExt/
sudo chown -R www-data:www-data /var/www/html
sudo chmod -R 775 /var/www/html
sudo rm -Rf /tmp/JeedouinoExt*

echo "== Installation des dependances Python ..."
echo "================================="
# installation des dependances Python
sudo apt-get -y install build-essential python3-pip python3-setuptools python-serial python3-dev python3-openssl git
sudo pip3 install --upgrade setuptools pip
sudo pip3 install wheel
sudo pip3 install pyserial

echo "== Installation RPi.GPIO  ..."
echo "================================="
sudo pip3 install RPi.GPIO

echo "== Installation de la lib Adafruit_Python_DHT  ..."
echo "================================="
rm -Rf Adafruit_Python_DHT
git clone https://github.com/adafruit/Adafruit_Python_DHT.git
sudo pip3 install /Adafruit_Python_DHT

echo "== Installation de la lib Adafruit_Python_BMP085/180  ..."
echo "================================="
rm -Rf Adafruit_Python_BMP
git clone https://github.com/adafruit/Adafruit_Python_BMP.git
sudo pip3 install /Adafruit_Python_BMP

echo "== Installation de la lib ABElectronics_Python_Libraries  ..."
echo "================================="
rm -Rf ABElectronics_Python_Libraries
git clone https://github.com/abelectronicsuk/ABElectronics_Python_Libraries.git
sudo pip3 install /ABElectronics_Python_Libraries

echo "== Installation de la lib danjperron/BitBangingDS18B20  ..."
echo "================================="
rm -Rf BitBangingDS18B20
git clone https://github.com/danjperron/BitBangingDS18B20.git
sudo pip3 install /BitBangingDS18B20/python

echo "== Installation de la lib Adafruit_Python_BME280  ..."
echo "================================="
pip3 install adafruit-circuitpython-lis3dh
sudo pip3 install adafruit-circuitpython-bme280
sudo pip3 install adafruit-circuitpython-bmp280

echo "== Installation de la lib Adafruit_Python_BME680  ..."
echo "================================="
sudo pip3 install adafruit-circuitpython-bme680

echo "================================="
echo "== Fin de l'installation ..."
echo "================================="
