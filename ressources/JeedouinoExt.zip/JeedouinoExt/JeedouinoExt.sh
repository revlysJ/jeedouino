##
# Jeedouino Install déportée sans Jeedom
# v0.2 alpha
##
echo "================================="
echo "== JeedouinoExt v0.21 alpha"
echo "== Debut de l'installation ..."
echo "================================="
echo "== Desactivation de Apache si present."
# Au cas où il y a déja Apache
# Désactiver le serveur Apache
sudo /etc/init.d/apache2 stop 
# Ne pas lancer Apache au démarrage
sudo systemctl disable apache2

echo "== Mises a jour du systeme en cours ..."
echo "/!\ Peut etre long suivant votre systeme."
echo "================================="
# Mettre a jour le systeme
sudo apt-get -y update
sudo apt-get -y upgrade
sudo apt-get -y dist-upgrade

echo "== Installation des dependances Python ..."
echo "================================="
# installation des dependances Python
sudo apt-get -y install build-essential python-pip python-serial python-dev python-openssl git
echo "== Installation de la lib DHT Python ..."
echo "================================="
git clone https://github.com/adafruit/Adafruit_Python_DHT.git
cd Adafruit_Python_DHT
sudo python setup.py install
cd ..

echo "== Installation de Nginx pour Raspbian ..."
echo "================================="
# Installer le serveur Nginx pour Raspbian
sudo apt-get -y --yes --force-yes install aptitude
sudo aptitude install -y nginx php5-fpm
echo "== Installation de crontab  ..."
echo "================================="
# Installer le crontab
sudo apt-get install cron

echo "== Configuration de Nginx  ..."
echo "================================="
# Configuration Nginx
sudo cp nginx_default /etc/nginx/sites-available/default

echo "== Copie des fichiers JeedouinoExt et mise en place des droits  ..."
echo "================================="
# Il ne nous reste plus qu’à modifier les droits 
sudo chmod -R 775 /var/www/
sudo mkdir -p /var/www/html/log
sudo mkdir -p /var/www/html/JeedouinoExt
sudo cp -r $(pwd)/*  /var/www/html/JeedouinoExt/
sudo chown -R www-data:www-data /var/www/html/JeedouinoExt

echo "== Creation du cronjob ..."
echo "================================="
# Creation du cronjob pour les relances auto apres redemarrage
JeedouinoCron="`crontab -l | grep -e 'JeedouinoCron.php'`"
if [ -z "${JeedouinoCron}" ] ; then
	croncmd="su --shell=/bin/bash - www-data -c '/usr/bin/php /var/www/html/JeedouinoExt/JeedouinoCron.php' >> /dev/null 2>&1"
	cronjob="* * * * * $croncmd"
	( crontab -l | grep -v "$croncmd" ; echo "$cronjob" ) | crontab -
fi	
crontab -l
echo "www-data ALL=(ALL) NOPASSWD: ALL" | (EDITOR="tee -a" visudo)

echo "== Creation de fichiers HTML/PHP pour tests ..."
echo "================================="
# ajouter un fichier « index.php » pour vérifier que PHP fonctionne
echo "<?php header('location: JeedouinoExt/JeedouinoExt.php'); ?>" > /var/www/html/index.php
echo "<?php header('location: JeedouinoExt.php'); ?>" > /var/www/html/JeedouinoExt/index.php
# ajouter un fichier « index.html » pour vérifier que Nginx fonctionne (Si Erreur 403 forbidden)
echo 'HTML OK - Nginx marche !<br><br>Essayez <a href="/JeedouinoExt/">JeedouinoExt</a>' > /var/www/html/index.html
echo 'HTML OK <br><br>Essayez en php <a href="index.php">JeedouinoExt.php</a>' > /var/www/html/JeedouinoExt/index.html

echo "== Redemarrage de Nginx ..."
echo "==========================c======="
# redémarrer Nginx, afin d’appliquer les modifications
sudo /etc/init.d/nginx restart

echo "================================="
echo "== Fin de l'installation ..."
echo "================================="
