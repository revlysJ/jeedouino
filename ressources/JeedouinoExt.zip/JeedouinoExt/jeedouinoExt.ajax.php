<?php
/* This file is part of Jeedouino, plugin of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */
 
 include 'jeedouinoExt.inc.php';	
 

	// POST_log();
	// GET_log() ;

try {
	
    // Actions pour la gestion du démon piFace / Jeedouino
 	if (init('action') == 'StartPiFaceDemon') 
    {
        StartDemonCMD(init('boardid'),'PiFace');		
		success();
	}   
  	if (init('action') == 'ReStartPiFaceDemon') 
    {
        ReStartDemonCMD(init('boardid'),'PiFace');		
		success();
	}   
 	if (init('action') == 'StopPiFaceDemon') 
    {
        StopDemonCMD(init('boardid'),'PiFace');		
		success();
	} 
 	if (init('action') == 'DeletePiFaceDemon')
    {
		EraseDemonFileCMD(init('boardid'),'PiFace');
		success();
	}
    // Actions pour la gestion du démon piGPIO / Jeedouino
 	if (init('action') == 'StartPiGpioDemon') 
    {
        StartDemonCMD(init('boardid'),'PiGpio');		
		success();
	}   
  	if (init('action') == 'ReStartPiGpioDemon') 
    {
        ReStartDemonCMD(init('boardid'),'PiGpio');		
		success();
	}   
 	if (init('action') == 'StopPiGpioDemon') 
    {
        StopDemonCMD(init('boardid'),'PiGpio');
		success();
	}
 	if (init('action') == 'DeletePiGpioDemon')
    {
		EraseDemonFileCMD(init('boardid'),'PiGpio');
		success();
	}
    // Actions pour la gestion du démon PiPlus / Jeedouino
 	if (init('action') == 'StartPiPlusDemon') 
    {
        StartDemonCMD(init('boardid'),'PiPlus');		
		success();
	}   
  	if (init('action') == 'ReStartPiPlusDemon') 
    {
        ReStartDemonCMD(init('boardid'),'PiPlus');	
		success();
	}   
 	if (init('action') == 'StopPiPlusDemon') 
    {
        StopDemonCMD(init('boardid'),'PiPlus');		
		success();
	}
 	if (init('action') == 'DeletePiPlusDemon')
    {
		EraseDemonFileCMD(init('boardid'),'PiPlus');
		success();
	}
    // Actions pour la gestion du démon ArduinoUsb / Jeedouino
 	if (init('action') == 'StartUSBDemon') 
    {
        StartDemonCMD(init('boardid'),'USB');		
		success();
	}   
  	if (init('action') == 'ReStartUSBDemon') 
    {
        ReStartDemonCMD(init('boardid'),'USB');		
		success();
	}   
 	if (init('action') == 'StopUSBDemon') 
    {
        StopDemonCMD(init('boardid'),'USB');		
		success();
	}
 	if (init('action') == 'DeleteUSBDemon')
    {
		EraseDemonFileCMD(init('boardid'),'USB');
		success();
	}
	// Actions pour les logs
 	if (init('action') == 'DeleteUSBLog')
    {
		EraseLogFileCMD('USB');
		success();
	}
 	if (init('action') == 'DeletePiPlusLog')
    {
		EraseLogFileCMD('PiPlus');
		success();
	}	
 	if (init('action') == 'DeletePiGpioLog')
    {
		EraseLogFileCMD('PiGpio');
		success();
	}
 	if (init('action') == 'DeletePiFaceLog')
    {
		EraseLogFileCMD('PiFace');
		success();
	}
 	if (init('action') == 'DeleteExtLog')
    {
		EraseLogFileCMD('Ext');
		success();
	}
    // Installation des dépendances
  	if (init('action') == 'installUpdate') 
    {
        exec('sudo `which apt-get` -y update >> JeedouinoExt.log 2>&1 &');		
		success();
	}   
  	if (init('action') == 'FilesUpdate') 
    {
        exec('sudo /bin/bash JeedouinoExt.maj >> JeedouinoExt.log 2>&1 &');		
		success();
	} 	
  	if (init('action') == 'installPython') 
    {
        exec('sudo /bin/bash Jeedouino.sh >> JeedouinoExt.log 2>&1 &');		
		success();
	}   	
  	if (init('action') == 'installGPIO')
    {
        exec('sudo `which pip` install RPi.GPIO >> JeedouinoPiGpio.log 2>&1 &');		
		success();
	}   
 	if (init('action') == 'installPIFACE') 
    {
        exec('sudo `which apt-get` -y install python-pifacedigitalio >> JeedouinoPiFace.log 2>&1 &');	
		success();
	}      
 	if (init('action') == 'installPiPlus') 
    {
        exec('sudo `which apt-get` -y install python-smbus >> JeedouinoPiPlus.log 2>&1 &');		
		success();
	} 
    // redemarrage / extinction
  	if (init('action') == 'installReboot') 
    {
        exec('sudo /sbin/reboot >> JeedouinoExt.log 2>&1 &');		
		success();
	}    	
  	if (init('action') == 'installShutdown') 
    {
        exec('sudo /sbin/shutdown >> JeedouinoExt.log 2>&1 &');		
		success();
	}	
    // action qui permet d'effectuer la sauvegarde des données en asynchrone
    throw new Exception('Aucune methode correspondante à : '. __FILE__ . ' >>> '.init('action'));
    /*     * *********Catch exeption*************** */
} catch (Exception $e) {
    //ajax::error(displayExeption($e), $e->getCode());
	file_put_contents('ajaxError.txt',$e." ".$e->getCode());
}
?>