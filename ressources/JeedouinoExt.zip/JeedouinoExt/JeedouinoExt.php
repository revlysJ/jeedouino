<?php
/* This file is part of Jeedouino, plugin of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom and the jeedouino plugin are distributed in the hope that they will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */

$this_file = "JeedouinoExt.php";
if (isset($_SERVER['REQUEST_URI']))	
{
	$this_url = $_SERVER['REQUEST_URI']; //__FILE__; 
}
else
{
	$this_url = $_SERVER['PHP_SELF']; //__FILE__; 
}

$this_url = str_replace($this_file ,'' , $this_url );
$p0 = strpos($this_url, '?');
if ($p0 !== false) $this_url = substr($this_url, 0 , $p0); // supprime les params après ? dans l'url reçue.
if (isset($_SERVER['SERVER_PORT']))	
{
	$this_port = $_SERVER['SERVER_PORT']; //__FILE__; 
}
else
{
	$this_port = 80;
}

include 'jeedouinoExt.inc.php';	
 //POST_log();
 //GET_log() ;

// Gestion $_POST[''] : SetJeedomCFG  SetPRM  $CallCmd
// from this Html Form
if (isset($_POST['SetCFG']))	
{
	if (isset($_POST['IP']) && isset($_POST['Port']))
	{
		if (!isset($_POST['Cpl'])) $cpl = '';
		else $cpl = $_POST['Cpl'];
		SetJeedomCFG($_POST['IP'] ,$_POST['Port'] , $cpl);
		header('location: '.$this_file);
	}
}
sleep(1);

$cfg = GetJeedomCFG();
Jlog( 'debug', 'GetJeedomCFG = '.$cfg);
if ($cfg !== false) 
{
	$_CFG = json_decode($cfg, true);
	$JeedomURL = '' . $_CFG['IP'] . ':' . $_CFG['Port'] . $_CFG['Cpl'] . '/';
}
else 
{
	$_CFG = array('IP' => '', 'Port' => '', 'Cpl' => '');
	$JeedomURL = '';
}

$UsbMapping = getUsbMapping();
if ($_CFG['IP'] != '') 
{
	$param = 'ip='.GetJeedouinoIP();
	$param .= '&port='.$this_port;
	$param .= '&path='.urlencode($this_url);
	$param .= '&usbMapping='.urlencode(json_encode($UsbMapping));
	//$reponse = CallbackExt($_CFG['IP'], $_CFG['Port'], $param);
	$url = 'http://'.$_CFG['IP']. ':'. $_CFG['Port']. $_CFG['Cpl']. '/plugins/jeedouino/core/php/CallbackExt.php?'. $param;
	$reponse = file_get_contents($url);
	Jlog( 'debug', 'Call '. $_CFG['IP']. ':'. $_CFG['Port']. ' - '. $reponse);
}

// From Jeedom
if (isset($_GET['SetJeedomCFG'])) 
{
	Jlog( 'debug', 'SetJeedomCFG = '.$_GET['SetJeedomCFG']);

	// from $prm = json_encode(array('IP' => $JeedomIP, 'Port' => $JeedomPort, 'Cpl' => $JeedomCPL));
	$params = json_decode($_GET['SetJeedomCFG'], true);
	if (isset($params['IP']) && isset($params['Port']) && isset($params['Cpl']))
	{
		SetJeedomCFG($params['IP'] ,$params['Port'] ,$params['Cpl']);
		echo 'OK';
		die();
	}
	echo 'SetJeedomCFG non valide : ' . $_GET['SetJeedomCFG'];
	die();
}
if (isset($_GET['SetPRM']))
{
	Jlog( 'debug', 'SetPRM recu avec : ' . $_GET['SetPRM']);
	// from $prm = json_encode(array('board_id' => $arduino_id, 'DemonName' => $DemonName, 'prm' => $setprm));
	$params = json_decode($_GET['SetPRM'], true);
	if (isset($params['board_id']) && isset($params['DemonName']) && isset($params['prm']))
	{
		Jlog( 'debug', 'SetPRM executé avec : ' . $params['board_id'] . ' , ' . $params['DemonName'] . ' , ' . $params['prm']);
		SetPRM($params['board_id'] ,$params['DemonName'] ,$params['prm']);
		echo 'OK';
		die();
	}
	Jlog( 'debug', 'SetPRM non executé avec : ' . $_GET['SetPRM']);
	echo 'SetPRM non valide : ' . $_GET['SetPRM'];
	die();
}	
	// Actions pour la gestion des démons / Jeedouino
 	if (isset($_GET['StartBoardDemonCMD']))
    {
		$params = json_decode($_GET['StartBoardDemonCMD'], true);
        if (StartDemonCMD($params['eqLogic'], $params['DemonType'])) echo 'OK';
		else echo 'NOK';
		die();
	}   
  	if (isset($_GET['ReStartBoardDemonCMD']))
    {
		$params = json_decode($_GET['ReStartBoardDemonCMD'], true);
        if (ReStartDemonCMD($params['eqLogic'], $params['DemonType'])) echo 'OK';
		else echo 'NOK';
		die();
	}   
 	if (isset($_GET['StopBoardDemonCMD']))
    {
		$params = json_decode($_GET['StopBoardDemonCMD'], true);
        if (StopDemonCMD($params['eqLogic'], $params['DemonType'])) echo 'OK';
		else echo 'NOK';
		die();
	}
 	if (isset($_GET['EraseBoardDemonFileCMD']))
    {
		$params = json_decode($_GET['EraseBoardDemonFileCMD'], true);
        if (EraseDemonFileCMD($params['eqLogic'], $params['DemonType'])) echo 'OK';
		else echo 'NOK';
		die();
	}	
	// Actions pour la gestion du démon piFace / Jeedouino
 	if (isset($_GET['StartPiFaceDemonCMD']))
    {
		$params = json_decode($_GET['StartPiFaceDemonCMD'], true);
        StartDemonCMD($params['eqLogic'],'PiFace');		 
		echo 'OK';
		die();
	}   
  	if (isset($_GET['ReStartPiFaceDemonCMD']))
    {
		$params = json_decode($_GET['ReStartPiFaceDemonCMD'], true);
        ReStartDemonCMD($params['eqLogic'],'PiFace');  
		echo 'OK';
		die();
	}   
 	if (isset($_GET['StopPiFaceDemonCMD']))
    {
		$params = json_decode($_GET['StopPiFaceDemonCMD'], true);
        StopDemonCMD($params['eqLogic'],'PiFace');  
		echo 'OK';
		die();
	}
 	if (isset($_GET['ErasePiFaceDemonFileCMD']))
    {
		$params = json_decode($_GET['ErasePiFaceDemonFileCMD'], true);
        EraseDemonFileCMD($params['eqLogic'],'PiFace');
		echo 'OK';
		die();
	}		
    // Actions pour la gestion du démon piGPIO / Jeedouino
 	if (isset($_GET['StartPiGpioDemonCMD']))
    {
		$params = json_decode($_GET['StartPiGpioDemonCMD'], true);
        StartDemonCMD($params['eqLogic'],'PiGpio');  
		echo 'OK';
		die();
	}   
  	if (isset($_GET['ReStartPiGpioDemonCMD']))
    {
		$params = json_decode($_GET['ReStartPiGpioDemonCMD'], true);
        ReStartDemonCMD($params['eqLogic'],'PiGpio');  
		echo 'OK';
		die();
	}   
 	if (isset($_GET['StopPiGpioDemonCMD']))
    {
		$params = json_decode($_GET['StopPiGpioDemonCMD'], true);
        StopDemonCMD($params['eqLogic'],'PiGpio'); 
		echo 'OK';
		die();
	}
 	if (isset($_GET['ErasePiGpioDemonFileCMD']))
    {
		$params = json_decode($_GET['ErasePiGpioDemonFileCMD'], true);
        EraseDemonFileCMD($params['eqLogic'],'PiGpio');
		echo 'OK';
		die();
	}	
    // Actions pour la gestion du démon PiPlus / Jeedouino
 	if (isset($_GET['StartPiPlusDemonCMD']))
    {
		$params = json_decode($_GET['StartPiPlusDemonCMD'], true);
        StartDemonCMD($params['eqLogic'],'PiPlus');  
		echo 'OK';
		die();
	}   
  	if (isset($_GET['ReStartPiPlusDemonCMD']))
    {
		$params = json_decode($_GET['ReStartPiPlusDemonCMD'], true);
        ReStartDemonCMD($params['eqLogic'],'PiPlus');	 
		echo 'OK';
		die();
	}   
 	if (isset($_GET['StopPiPlusDemonCMD']))
    {
		$params = json_decode($_GET['StopPiPlusDemonCMD'], true);
        StopDemonCMD($params['eqLogic'],'PiPlus');  
		echo 'OK';
		die();
	}
 	if (isset($_GET['ErasePiPlusDemonFileCMD']))
    {
		$params = json_decode($_GET['ErasePiPlusDemonFileCMD'], true);
        EraseDemonFileCMD($params['eqLogic'],'PiPlus');
		echo 'OK';
		die();
	}
    // Actions pour la gestion du démon ArduinoUsb / Jeedouino
 	if (isset($_GET['StartArduinoUsbDemonCMD']))
    {
		$params = json_decode($_GET['StartArduinoUsbDemonCMD'], true);
        StartDemonCMD($params['eqLogic'],'USB');  
		echo 'OK';
		die();
	}   
  	if (isset($_GET['ReStartArduinoUsbDemonCMD']))
    {
		$params = json_decode($_GET['ReStartArduinoUsbDemonCMD'], true);
        ReStartDemonCMD($params['eqLogic'],'USB');  
		echo 'OK';
		die();
	}   
 	if (isset($_GET['StopArduinoUsbDemonCMD']))
    {
		$params = json_decode($_GET['StopArduinoUsbDemonCMD'], true);
        StopDemonCMD($params['eqLogic'],'USB'); 
		echo 'OK';
		die();
	}
 	if (isset($_GET['EraseArduinoUsbDemonFileCMD']))
    {
		$params = json_decode($_GET['EraseArduinoUsbDemonFileCMD'], true);
        EraseDemonFileCMD($params['eqLogic'],'USB');
		echo 'OK';
		die();
	}


// html stuff
//<meta http-equiv = "Refresh" content="60">
?>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>Jeedouino & JeedouinoExt - Jeedom Plugin</title>
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<meta name="author" content="">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<link rel="SHORTCUT ICON" href="/JeedouinoExt/favicon.ico">
		<link rel="stylesheet" href="/JeedouinoExt/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="/JeedouinoExt/jquery.ui/jquery-ui.css">
		<link rel="stylesheet" href="/JeedouinoExt/font-awesome/css/font-awesome.min.css">
		<script src="/JeedouinoExt/jquery/jquery.min.js"></script>
		<script src="/JeedouinoExt/jquery.ui/jquery-ui.min.js"></script>	
		<script src="/JeedouinoExt/bootstrap/bootstrap.min.js"></script>	
		<style>
			.well {
				display:none;
				margin:1em;
				max-width: 1170px;
			}
			.well .popup_close {
				position: absolute;
				top: 0;
				right: 0px;
				border-radius: 2px;
				background: none;
				border: 0;
				font-size: 25px;
				padding: 0 10px;
			}
		</style>	
	</head>
	<body>
	<div class="col-lg-12 alert alert-success">
	<h1>JeedouinoExt v0.97 Alpha (c) Revlys</h1>
	<span id="github" class="pull-right"> <a class="btn btn-success btn-xs" target="_blank" href="https://github.com/revlysJ/jeedouino"><i class="fa fa-book"></i> Jeedouino on Github</a></span>
	<span id="span_plugin_doc" class="pull-right"><a class="btn btn-info btn-xs" target="_blank" href="https://revlysj.github.io/jeedouino/fr_FR/"><i class="fa fa-book"></i> Documentation</a></span>
	</div>
	<div class="col-lg-12 alert alert-info">
	<span>Pensez à réactualiser cette page (F5) pour voir les changements éventuels.</span>
	<a class="btn btn-success pull-right"><i class="fa fa-clock-o"></i> <span id="horloge"></span></a>
	</div>
	<div style="display: none; width: 100%;" id="div_alert"></div>
	
	<ul class="nav nav-tabs" role="tablist">
		<li role="presentation"><a href="#jeedouinoExtConfigtab" aria-controls="home" role="tab" data-toggle="tab"><i class="fa fa-cogs"></i> Jeedom Maître</a></li>
		<li role="presentation"><a href="#jeedouinoExtRPItab" aria-controls="profile" role="tab" data-toggle="tab"><i class="fa fa-wrench"></i> Raspberry PI</a></li>
		<li role="presentation"><a href="#jeedouinoExtDEPtab" aria-controls="profile" role="tab" data-toggle="tab"><i class="fa fa-download"></i> Dépendances</a></li>
		<li role="presentation" class="active"><a href="#jeedouinoExtDEMONtab" aria-controls="profile" role="tab" data-toggle="tab"><i class="fa fa-list-alt"></i> Equipements et Démons</a></li>
	</ul>

<?php // Bloc 1 ?>
	<div class="tab-content" style="height:calc(100% - 300px);overflow:auto;overflow-x: hidden;">
		<div role="tabpanel" class="tab-pane" id="jeedouinoExtConfigtab">
			<br>		
			<form class="form-horizontal" method="POST">
			<fieldset style=" border: 1px solid #cccccc;"> 	
			<label class="alert alert-danger">Informations sur le Jeedom Maître</label>    
				<div class="form-group alert alert-danger" style="margin: 10px; border: 1px solid;">
					<div class="ipsource">
					   <div class="form-group">
							<label class="col-sm-2 control-label">IP</label>
							<div class="col-sm-5">
								<input type="text" class="configKey form-control"  name="IP" placeholder="ex : 192.168.0.55" value="<?php echo $_CFG['IP']; ?>"/>
							</div>
						</div> 	
						<div class="form-group" >					
							<label class="col-sm-2 control-label">Port</label>
							<div class="col-sm-5">
								<input type="text" class="configKey form-control"  name="Port" placeholder="ex : 80" value="<?php echo $_CFG['Port']; ?>"/>
							</div>       
						</div> 	
						<div class="form-group" >					
							<label class="col-sm-2 control-label">Complément</label>
							<div class="col-sm-5">
								<input type="text" class="configKey form-control"  name="Cpl" placeholder="ex : /jeedom" value="<?php echo $_CFG['Cpl']; ?>"/>
							</div>    					
						</div>
					</div>	
				</div>
				<input  type="submit" class="btn btn-success pull-right" name="SetCFG">
			</fieldset> 
			</form>
		</div> 	
<?php // Bloc 3 ?>		
		<div role="tabpanel" class="tab-pane" id="jeedouinoExtDEPtab">
			<br>		
			<form class="form-horizontal">
			<fieldset style=" border: 1px solid #cccccc;"> 	
				<label class="alert alert-info">Dépendances pour les démons de Jeedouino</label>    
				<div class="form-group alert alert-info" style="margin: 10px; border: 1px solid;">
					<div class="form-group" >
							<label class="col-lg-5 control-label">RPi.GPIO Installation</label>
							<div class="col-lg-5">
									<a class="btn btn-info bt_installGPIO" ><i class="fa fa-play"></i> sudo install RPi.GPIO</a>
							</div>            
					</div> 
					<div class="form-group" >
							<label class="col-lg-5 control-label">PiFace Digitalio Installation</label>
							<div class="col-lg-5">
									<a class="btn btn-info bt_installPIFACE" ><i class="fa fa-play"></i> sudo install python-pifacedigitalio</a>
							</div>            
					</div>      
					<div class="form-group" >
							<label class="col-lg-5 control-label">IO.PiPlus / MCP23017 smbus Installation</label>
							<div class="col-lg-5">
									<a class="btn btn-info bt_installPiPlus" ><i class="fa fa-play"></i> sudo install python-smbus</a>
							</div>            
					</div> 	
				</div> 	
			</fieldset>
			</form>
		</div> 	

<?php // Bloc 2 ?>	
		<div role="tabpanel" class="tab-pane" id="jeedouinoExtRPItab">
			<br>
			<form class="form-horizontal">
			<fieldset style=" border: 1px solid #cccccc;"> 	
				<label class="alert alert-warning">Configuration de ce Système</label>    
				<span id="span_phpinfo" class="pull-right"><a class="btn btn-info btn-xs" target="_blank" href="phpinfo.php"><i class="fa fa-book"></i> PhpInfo();</a></span>
				
				<div class="form-group alert alert-warning" style="margin: 10px; border: 1px solid;">
					<div class="form-group" >
							<label class="col-lg-5 control-label">MàJ Système</label>
							<div class="col-lg-5">
									<a class="btn btn-info bt_installUpdate" ><i class="fa fa-play"></i> sudo apt-get update</a>
							</div>            
					</div> 	
		<?php /*
					<div class="form-group" >
							<label class="col-lg-5 control-label">Install Python Serial / DHT</label>
							<div class="col-lg-5">
									<a class="btn btn-info bt_installPython" ><i class="fa fa-play"></i> sudo /bin/bash Jeedouino.sh</a>
							</div>            
					</div> 		
		*/ ?>			
					<div class="form-group" >
							<label class="col-lg-5 control-label">Redémarrer le système</label>
							<div class="col-lg-5">
									<a class="btn btn-warning bt_installReboot" ><i class="fa fa-play"></i> sudo reboot</a>
							</div>            
					</div> 	
					<div class="form-group" >
							<label class="col-lg-5 control-label">Eteindre le système</label>
							<div class="col-lg-5">
									<a class="btn btn-danger bt_installShutdown" ><i class="fa fa-play"></i> sudo shutdown</a>
							</div>            
					</div> 
					<div class="form-group" >
							<label class="col-lg-5 control-label">IP : PORT / PATH </label>
							<div class="col-lg-5">
									<a class="btn btn-info " ><i class="fa fa-sitemap"></i> <?php echo GetJeedouinoIP() . ' : ' . $this_port . $this_url;  ?></a>
							</div>            
					</div> 				
					<div class="form-group">
						<label class="col-lg-5 control-label">Port USB disponibles</label>
						<div class="col-lg-5">
							<select class="form-control" >
									<?php
									foreach ($UsbMapping as $name => $value) 
									{
										echo '<option value="' . $name . '">' . $name . ' (' . $value . ')</option>';
									}
									?>
							</select>
						</div>
					</div>	
					<div class="form-group" >
							<label class="col-lg-5 control-label">Logs JeedouinoExt</label>
							<div class="col-lg-5">
								<a class="btn btn-info bt_test JPO_open" log="JeedouinoExt.log"><i class="fa fa-pencil-square-o"></i></i> JeedouinoExt</a>
								<a class="btn btn-danger bt_vider" logfile="JeedouinoExt.log"><i class="fa fa-eraser"></i></a>
							</div>             
					</div> 			
				</div>
			</fieldset> 
			</form>
		</div> 	
<?php // Bloc 5 
	$jeedouinoPATH = realpath(dirname(__FILE__));
	$filename = $jeedouinoPATH.'/jeedouinoPrm.prm';	
	$status = file_exists($filename);
	$ctext = $status ? 'success' : 'danger';
?>
		<div role="tabpanel" class="tab-pane active" id="jeedouinoExtDEMONtab">
			<br>		
			<form class="form-horizontal">
			<fieldset style=" border: 1px solid #cccccc;"> 	
				<label class="alert alert-<?php echo $ctext; ?>">Gestion des équipements avec démons sur ce RPI</label>
				<span class="btn btn-success pull-right">Logs JeedouinoExt
					<a class="btn btn-info bt_test JPO_open" log="JeedouinoExt.log"><i class="fa fa-pencil-square-o"></i></i></a>
					<a class="btn btn-danger bt_vider" logfile="JeedouinoExt.log"><i class="fa fa-eraser"></i></a>
				</span>

				<div class="form-group alert alert-<?php echo $ctext; ?>" style="margin: 10px; border: 1px solid;">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th>Equipement</th>				
								<th>Statut</th>
								<th>(Re)Démarrer</th>
								<th>Arrêter</th>
								<th>Type</th>
								<th>Port</th>
								<th>Logs</th>
							</tr>
						</thead>
						<tbody>
						<?php
							if ($status) 
							{
								$file = file_get_contents($filename);
								$prm = json_decode($file, true);
								foreach ($prm as $board_id => $board_prm)
								{
									$DemonName = $board_prm['DemonName'];
									$port = $board_prm['Port'];
									$StatusDemon = StatusDemonCMD($board_id, $DemonName);
									?>
									<tr>
										<td>
											<?php 
												echo '<div class="col-lg-7"><a class="btn btn-default " target="_blank" href="http://'.$JeedomURL.'index.php?&v=d&p=jeedouino&m=jeedouino&id='.$board_id.'"><i class="fa fa-sitemap"></i> EqID  '.$board_id.'</a> '; 
												echo '<a class="btn btn-danger bt_Delete'.$DemonName.'Demon" boardID="'. $board_id.'"><i class="fa fa-eraser"></i> Eff</a></div>';
											?>
										</td>									
										<td class="deamonState">
											<?php
												if ($StatusDemon) echo '<span class="btn btn-success" >OK</span>';
												else echo '<span class="btn btn-danger tooltips" >NOK</span>';
											?>
										</td>
										<td>
											<?php
												if ($StatusDemon) echo '<a class="btn btn-success bt_ReStart'.$DemonName.'Demon" boardID="'. $board_id.'"><i class="fa fa-refresh"></i></a>';
												else echo '<a class="btn btn-success bt_Start'.$DemonName.'Demon" boardID="'. $board_id.'"><i class="fa fa-play"></i></a>';
											?>  
										</td>
										<td>
											<?php
												if ($StatusDemon) echo '<a class="btn btn-danger bt_Stop'.$DemonName.'Demon" boardID="'. $board_id.'"><i class="fa fa-stop"></i></a>';
											?>  
										</td>
										<td><?php echo $DemonName; ?></td>
										<td><?php echo $port; ?></td>
										<td>
											<a class="btn btn-info bt_test JPO_open" log="Jeedouino<?php echo $DemonName; ?>.log"><i class="fa fa-pencil-square-o"></i></i></a>
											<?php
												echo '<a class="btn btn-danger bt_vider" logfile="Jeedouino' . $DemonName . '.log"><i class="fa fa-eraser"></i></a>';
											?>  									
										</td>
								
									</tr>
									<?php
								}
							}
							else
							{
								echo '<tr><td colspan="7"><span class="label label-danger tooltips" style="font-size : 1em;" >Veuillez re-sauver vos équipements JeedouinoExt dans Jeedom. Merci.</span></td></tr>';
							}
							?>
						</tbody>
					</table>	
				</div>
			</fieldset>
			</form>
		</div> 	
	</div>
	
<div id="JPO" class="well">
<a class="btn btn-success" id="bt_downloadLog" download href="" target="_blank"><i class="fa fa-download"></i> Télécharger</a>
<a class="btn btn-warning" id="bt_pause" logfile=""><i class="fa fa-pause"></i> Pause</a>
<a class="btn btn-danger bt_vider" id="bt_vider" logfile=""><i class="fa fa-eraser"></i> Vider</a>
<br><br>
<pre id="modal_log" style='overflow: auto; height: 80%; width:100%;'></pre>
</div>

<script src="JeedouinoExt.js"></script>
<script src="/JeedouinoExt/jquery/jquery.popupoverlay.min.js"></script>	
<script>
setInterval(function () {
  var JeedouinoExt = new Date;
  $('#horloge').text(JeedouinoExt.toLocaleTimeString());
}, 1000);

timeout = null;
pause = 0;
$('#JPO').popup({
	closebutton: true,
	color: 'black',
	opacity: 0.5,
	onclose: function() {
		clearTimeout( timeout ); 
		pause = 0; 
		$('#modal_log').empty();
		$('#bt_pause').removeClass('btn-success').addClass('btn-warning');
		$('#bt_pause').html('<i class="fa fa-pause"></i> Pause');		
		},
});
$('.bt_vider').off('click').on('click', function () {
	if ( confirm('Etês-vous sûr de vouloir vider ce fichier ?' ) ) 
	{
		logf = $(this).attr('logfile');
		$('#div_alert').showAlert({message: '<i class="fa fa-spinner fa-spin fa-fw"></i> Purge du fichier de log ' + logf + ' en cours.', level: 'success'});
		$.ajax({
			type: "POST",
			url: "jeedouinoExt.ajax.php",
			data: {
				action: "DeleteLog",
				logfile : logf,
			},
			dataType: 'json',
			success: function (data) {
				if (data.state != 'ok') {
					$('#div_alert').showAlert({message: data.result, level: 'danger'});
					return;
				}					
				setTimeout(function(){ $('#div_alert').hide(); }, 3000);
			}
		});
	};
});
$('.bt_test').off('click').on('click', function () 
{
	$('#modal_log').empty();
	autoupdate({
		logfile : $(this).attr('log'),
		display : $('#modal_log'),
		});

	$('#bt_downloadLog').attr('href', $(this).attr('log'));
	$('#bt_vider').attr('logfile', $(this).attr('log'));
	$('#bt_pause').attr('logfile', $(this).attr('log'));
});
$('#bt_pause').off('click').on('click', function () 
{
	if (pause == 0)
	{
		pause = 1;
		$(this).removeClass('btn-warning').addClass('btn-success');
		$(this).html('<i class="fa fa-play"></i> Reprendre');
	}
	else
	{
		pause = 0;
		$(this).removeClass('btn-success').addClass('btn-warning');
		$(this).html('<i class="fa fa-pause"></i> Pause');
		autoupdate({
			logfile : $(this).attr('logfile'),
			display : $('#modal_log'),
			});		
	}
});
autoupdate = function (prm)
{
	if (pause == 1) return;
	$.ajax({
		type: "POST", 
		url: "jeedouinoExt.ajax.php",
		data: {
			action: 'getLog',
			logfile : prm.logfile,
		},
		dataType: 'json',
		success : function(data){
			var log = '';
			var regex = /<br\s*[\/]?>/gi;
			if ($.isArray(data.result))
			{
				for (var i in data.result) { log += $.trim(data.result[i]) + "\n"; }
			}
			prm.display.text(log);
			prm.display.scrollTop(prm.display.height() + 50000);
			if (timeout !== null) { clearTimeout( timeout ); }
			timeout = setTimeout( function() { autoupdate(prm) }, 2000 );
		},
		error : function(){
			if (timeout !== null) { clearTimeout( timeout ); }
			timeout = setTimeout( function() { autoupdate(prm) }, 2000 );
		},
	});
}
</script>
<?php
echo '<script>';


gen_button_confirm("installShutdown", 'Le système est en cours d arrêt.');
gen_button_confirm("installReboot", 'Le système est en cours de redémarrage.'); 
gen_button("installUpdate", 'Le système est en cours de mise à jour.');
gen_button("FilesUpdate", 'Les fichiers JeedouinoExt sont en cours de mise à jour.');
//gen_button("installPython", 'Les librairies Python Serial / DHT sont en cours d installation.');
gen_button("installPiPlus", 'Les dépendances IO.PiPlus sont en cours d installation.');
gen_button("installGPIO", 'Les dépendances RPI.GPIO sont en cours d installation.');
gen_button("installPIFACE", 'Les dépendances PIFACEDIGITALIO sont en cours d installation.');

gen_button("StartPiFaceDemon", 'Le démon va être démarré.');
gen_button("ReStartPiFaceDemon", 'Le démon va être (re)démarré.');
gen_button("StopPiFaceDemon", 'Le démon va être arreté.');
gen_button_confirm("DeletePiFaceDemon", 'Le démon va être éffacé.');

gen_button("StartPiGpioDemon", 'Le démon va être démarré.');
gen_button("ReStartPiGpioDemon", 'Le démon va être (re)démarré.');
gen_button("StopPiGpioDemon", 'Le démon va être arreté.');
gen_button_confirm("DeletePiGpioDemon", 'Le démon va être éffacé.');

gen_button("StartUSBDemon", 'Le démon va être démarré.');
gen_button("ReStartUSBDemon", 'Le démon va être (re)démarré.');
gen_button("StopUSBDemon", 'Le démon va être arreté.');
gen_button_confirm("DeleteUSBDemon", 'Le démon va être éffacé.');

gen_button("StartPiPlusDemon", 'Le démon va être démarré.');
gen_button("ReStartPiPlusDemon", 'Le démon va être (re)démarré.');
gen_button("StopPiPlusDemon", 'Le démon va être arreté.');
gen_button_confirm("DeletePiPlusDemon", 'Le démon va être éffacé.');

echo '</script>';
?>

</body>
</html>
