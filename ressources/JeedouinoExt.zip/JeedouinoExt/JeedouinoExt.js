/* This file is part of Jeedom, partly modified for the Jeedouino plugin.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */                
function isset() {
	var a = arguments, b = a.length, d = 0;
	if (0 === b)
		throw Error("Empty isset");
	for (; d !== b; ) {
		if (void 0 === a[d] || null === a[d])
			return!1;
		d++
	}
	return!0
}
function init(_value, _default) {
	if (!isset(_default)) {
		_default = '';
	}
	if (!isset(_value)) {
		return _default;
	}
	return _value;
}
/*********************jquery alert*************************************/
$.fn.showAlert = function (_options) 
{
	var options = init(_options, {});
	options.message = init(options.message, '');
	options.level = init(options.level, '');
	options.emptyBefore = init(options.emptyBefore, true);
	options.show = init(options.show, true);
	if ($.mobile) 
	{
		 new $.nd2Toast({
			message :  options.message, 
			ttl : 3000
		});
	} else {
		if (options.emptyBefore == false) {
			var html = $(this).find('.displayError').html();
			if (isset(html)) {
				options.message = html + '<br/>' + options.message;
			}
		}
		$(this).empty();
		$(this).html('<span href="#" class="btn_closeAlert pull-right cursor" style="position : relative; left : 30px;color : grey">×</span><span class="displayError">' + options.message + '</span>');
		$(this).removeClass('alert alert-warning alert-danger alert-info alert-success jqAlert');
		$(this).addClass('alert jqAlert');
		if (options.level != '') {
			$(this).addClass('alert-' + options.level);
		}
		if (options.show) {
			$(this).show();
			$(this).css('padding', '7px 35px 7px 15px');
			$(this).css('margin-bottom', '5px');
			$(this).css('overflow', 'auto');
			$(this).css('max-height', $(window).height() - 100 + 'px');
			$(this).css('z-index', '9999');
		}

		if ($(this).offset().top - $(window).scrollTop() < $(this).height()) {
			$('html, body').animate({
				scrollTop: $(this).offset().top - 60
			}, 650);
		}

		$(this).find('.btn_closeAlert').on('click', function () {
			$(this).closest('.jqAlert').hide();
		});
	}
    return this;
};