<?php
/* This file is part of Jeedouino, plugin of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom and the jeedouino plugin are distributed in the hope that they will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General License for more details.
 *
 * You should have received a copy of the GNU General License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */
 
date_default_timezone_set('Europe/Paris'); 
function init($m)
{
	return $_POST[$m];
}
 function success($_data = '') 
 {
        $return = array(
            'state' => 'ok',
            'result' => $_data
        );
        echo json_encode($return,JSON_UNESCAPED_UNICODE);
        die();
}
function getLog($logfile) 
{
	//Jlog('debug', 'Fichier de log demandé : ' . $logfile);
	$log = file($logfile);
	//Jlog('debug', 'lignes : ' . json_encode($log));
	if ($log !== false) return $log;
	else return [];
}
function getUsbMapping() 
{
	$usbMapping = array();
	foreach (scandir('/dev/') as $usb) 
	{
		if  (strpos($usb, 'ttyUSB') === false and strpos($usb, 'ttyACM') === false) continue;
			
		$vendor = '';
		$model = '';
		foreach (explode("\n", shell_exec('/sbin/udevadm info --name=/dev/' . $usb . ' --query=all')) as $line) 
		{
			if (strpos($line, 'E: ID_MODEL_FROM_DATABASE=') !== false) 
			{
				$model = trim(str_replace(array('E: ID_MODEL_FROM_DATABASE=', '"'), '', $line));
			}
			if (strpos($line, 'E: ID_VENDOR_FROM_DATABASE=') !== false) 
			{
				$vendor = trim(str_replace(array('E: ID_VENDOR_FROM_DATABASE=', '"'), '', $line));
			}
		}
		if ($vendor == '' && $model == '') 
		{
			$usbMapping['/dev/' . $usb] = '/dev/' . $usb;
		} 
		else 
		{
			$name = trim($vendor . ' ' . $model);
			$number = 2;
			while (isset($usbMapping[$name])) 
			{
				$name = trim($vendor . ' ' . $model . ' ' . $number);
				$number++;
			}
			$usbMapping[$name] = '/dev/' . $usb;
		}
	}

	if (file_exists('/dev/ttyAMA0')) {
		$usbMapping['Raspberry pi'] = '/dev/ttyAMA0';
	}
	if (file_exists('/dev/ttymxc0')) {
		$usbMapping['Jeedom board'] = '/dev/ttymxc0';
	}
	if (file_exists('/dev/S2')) {
		$usbMapping['Banana PI'] = '/dev/S2';
	}
	if (file_exists('/dev/ttyS2')) {
		$usbMapping['Banana PI (2)'] = '/dev/ttyS2';
	}
	if (file_exists('/dev/ttyS0')) {
		$usbMapping['Cubiboard'] = '/dev/ttyS0';
	}
	if (file_exists('/dev/ttyS3')) {
		$usbMapping['Orange PI'] = '/dev/ttyS3';
	}
	if (file_exists('/dev/ttyS1')) {
		$usbMapping['Odroid C2'] = '/dev/ttyS1';
	}	
	return $usbMapping;
}
 // end
 
 // save posts
function POST_log() 
{
	$m = date("Y-m-d H:i:s") ."\r\n"; 
	foreach ( $_POST as $key => $value )
	{
		$m.=$key. ' = '.$value." *** "."\r\n";
	}	
	file_put_contents('POST_log.txt',$m,FILE_APPEND);
}
function GET_log() 
{
	$m = date("Y-m-d H:i:s") ."\r\n"; 
	foreach ( $_GET as $key => $value )
	{
		$m.=$key. ' = '.$value." *** "."\r\n";
	}	
	file_put_contents('GET_log.txt',$m,FILE_APPEND);
}

 // Generate JS script for ajax buttons
 function gen_button($bt_id, $bt_message)
 {
	 echo "
    $('.bt_".$bt_id."').on('click', function () {
		$('#div_alert').showAlert({message: '<i class=\"fa fa-spinner fa-spin fa-fw\"></i> " . $bt_message . " >> F5 pour actualiser la page.', level: 'success'});
        $.ajax({// fonction permettant de faire de l'ajax
            type: \"POST\", // methode de transmission des données au fichier php
            url: \"jeedouinoExt.ajax.php\", // url du fichier php
            data: {
                action: \"".$bt_id."\",
				boardid : $(this).attr('boardID'),
            },
            dataType: 'json',

            success: function (data) { // si l'appel a bien fonctionné
            if (data.state != 'ok') {
                $('#div_alert').showAlert({message: data.result, level: 'danger'});
                return;
            }
			setTimeout(function(){ $('#div_alert').hide(); }, 3000);
        }
    });
    });
	";
 }
function gen_button_confirm($bt_id, $bt_message)
{
	echo "
    $('.bt_".$bt_id."').on('click', function () {
		if ( confirm('Etês-vous sûr de vouloir faire cette action ?' ) ) 
		{
			$('#div_alert').showAlert({message: '<i class=\"fa fa-spinner fa-spin fa-fw\"></i> " . $bt_message . "', level: 'success'});
			$.ajax({
				type: \"POST\",
				url: \"jeedouinoExt.ajax.php\",
				data: {
					action: \"".$bt_id."\",
					boardid : $(this).attr('boardID'),
				},
				dataType: 'json',
				success: function (data) {
					if (data.state != 'ok') {
						$('#div_alert').showAlert({message: data.result, level: 'danger'});
						return;
					}					
					setTimeout(function(){ $('#div_alert').hide(); }, 3000);
				}
			});
		};
    });
	";
}
 // fonctions issues de la class Jeedouino pour la gestion des démons
	function FilterDemon($DemonType)
	{
		$DemonType = trim(strtolower($DemonType)); 
		switch ($DemonType)
		{
			case 'usb':
			case 'arduinousb':
			case 'arduino':
			case 'auno':
			case 'a2009':
			case 'anano':
			case 'a1280':
			case 'a2560':
				return 'USB';
				break; 
			case 'piface':
			case 'face':
				return 'PiFace';
				break; 	
			case 'pigpio':
			case 'pigpio26':
			case 'pigpio40':
			case 'gpio':
				return 'PiGpio';
				break; 
			case 'piplus':
			case 'plus':
			case 'mcp':
				return 'PiPlus';
				break;
			case 'Ext':
			case 'ext':
			case 'EXT':
				return 'Ext';
				break; 	
		}
		Jlog( 'error', 'Impossible de trouver ce type de démon ( ' . ucfirst ($DemonType) . ' ).');
		return null;
	}	 
 	function GetJeedouinoIP() // on recupere l'adresse IP du maitre si dispo
	{
		$ip = @$_SERVER['SERVER_ADDR'];
		if ($ip != '' and $ip != '127.0.0.1') return $ip;	
		
		// On va essayer autrement.
		$reponse = exec("sudo  ifconfig | grep inet | head -1");
		// IP=$(ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{print $1}')
		// les regex c'est pas mon truc, donc je fait a l'ancienne ;-)
		//inet 192.168.0.42  netmask 255.255.255.0  broadcast 192.168.0.255
		//inet addr: 192.168.0.42  netmask 255.255.255.0  broadcast 192.168.0.255

		$reponse = str_replace('addr', '', $reponse);
		$reponse = str_replace(':', '', $reponse);
		$reponse = str_replace('inet', '', $reponse);
		$reponse = trim($reponse);
		$p0 = strpos($reponse, ' ');
		if ($p0 !== false)
		{
			$ip = trim(substr($reponse, 0, $p0));
			//Jlog( 'debug', 'L\'IP de ce JeedouinoExt est ' . $ip);
		}
		
		if (filter_var($ip, FILTER_VALIDATE_IP) !== false) return $ip;
		
		// pas d'IP alors erreur.
		Jlog( 'error', 'L\'IP de ce JeedouinoExt est introuvable. ip = '.$ip);
		return $ip;
	}
	function Jlog($log1, $log2) 
	{
		$logFile = '';
		$jeedouinoPATH = realpath(dirname(__FILE__));
		$logFileName = $jeedouinoPATH . '/JeedouinoExt.log';
		$maxLineLog = 500;
		if (file_exists($logFileName)) $logFile = file_get_contents($logFileName);
		$logFile .= date("Y-m-d H:i:s") . ' [ ' . strtoupper($log1) . ' ] ' . $log2 . "\r\n"; 
		file_put_contents($logFileName,$logFile);
		shell_exec('sudo chmod 777 ' . $logFileName . ' ;echo "$(tail -n ' . $maxLineLog . ' ' . $logFileName . ')" > ' . $logFileName);
	}
	function CallbackExt($ip,$port,$param) 
	{
		$message ="GET ?".$param." HTTP/1.1\r\n";
		$message .= "Host: ".GetJeedouinoIP()."\r\n";
		$message .= "Connection: Close\r\n\r\n";			
		$fp = @fsockopen($ip, $port, $errno, $errstr, 3);
		if ($fp===false)
		{
			Jlog( 'error', 'Erreur de connection au Jeedom maitre sur '.$ip.':'.$port.' - Réponse : '.$errno.' - '.$errstr);	
			return 'NOK';
		}
		stream_set_timeout($fp,6);
		fwrite($fp, $message);
		$reponse='';
		$debut = time();
		while (!feof($fp)) 
		{
			$reponse.=fgets($fp);
			if  ((time() - $debut) > 6) break;
		}
		fclose($fp);		 
		return trim($reponse);
	}		
	function GetJeedomCFG() 
	{
		$jeedouinoPATH = realpath(dirname(__FILE__));
		$filename = $jeedouinoPATH.'/jeedouino.cfg';		
		if (file_exists($filename)) return file_get_contents($filename);
		Jlog( 'debug', $filename . ' introuvable ! ');
		return false;
	}		
	function SetJeedomCFG($IP='',$Port='',$Cpl='') 
	{
		if ($IP == '')
		{
			Jlog( 'error', 'SetJeedomCFG $IP n est pas fourni !.');
			return;
		}
		if ($Port == '')
		{
			Jlog( 'error', 'SetJeedomCFG $Port n est pas fourni !.');
			return;
		}	
/* 		if ($Cpl == '')
		{
			Jlog( 'error', 'SetJeedomCFG $Cpl n est pas fourni !.');
			return;
		}	 */	
		$jeedouinoPATH = realpath(dirname(__FILE__));
		$filename=$jeedouinoPATH.'/jeedouino.cfg';		
		$prm = json_encode(array('IP' => $IP, 'Port' => $Port, 'Cpl' => $Cpl));
		file_put_contents($filename, $prm);
		Jlog( 'debug', $filename . ' créé avec : ' . $prm);
	}		
	function SetPRM($board_id='',$DemonName='',$prm='') 
	{
		if ($board_id == '')
		{
			Jlog( 'error', 'SetPRM $board_id n est pas fourni !.');
			return;
		}
		if ($DemonName == '')
		{
			Jlog( 'error', 'SetPRM $DemonName n est pas fourni !.');
			return;
		}	
		if ($prm == '')
		{
			Jlog( 'error', 'SetPRM $prm n est pas fourni !.');
			return;
		}		
		$jeedouinoPATH = realpath(dirname(__FILE__));
		$filename=$jeedouinoPATH.'/jeedouino'.$DemonName.'_'.$board_id.'.prm';		
		file_put_contents($filename, $prm);
		Jlog( 'debug', $filename . ' créé avec : ' . $prm);
		AddPRM($board_id, $DemonName, $prm);
		return;
	}	
	function AddPRM($board_id, $DemonName, $param) 
	{
		$jeedouinoPATH = realpath(dirname(__FILE__));
		$filename = $jeedouinoPATH.'/jeedouinoPrm.prm';		
		if (file_exists($filename)) 
		{
			$file = file_get_contents($filename);
			$prm = json_decode($file, true);
		}
		else $prm = array();
		$arr = explode(' ', $param);
		$port = $arr[0];
		
		$prm[$board_id] = array('DemonName' => $DemonName, 'Port' => $port );
		
		file_put_contents($filename, json_encode($prm));
		Jlog( 'debug', $filename . ' créé avec : ' . json_encode($prm));
	}
	function RemovePRM($board_id) 
	{
		$jeedouinoPATH = realpath(dirname(__FILE__));
		$filename = $jeedouinoPATH.'/jeedouinoPrm.prm';		
		if (file_exists($filename)) 
		{
			$file = file_get_contents($filename);
			$prm = json_decode($file, true);
			if (isset($prm[$board_id]))  unset($prm[$board_id]);
			file_put_contents($filename, json_encode($prm));			
			Jlog( 'debug', $filename . ' modifié ! RemovePRM('.$board_id.') effectué : '. json_encode($prm));
		}
		else Jlog( 'debug', $filename . ' introuvable! RemovePRM('.$board_id.') impossible.');
	}	
	function StartDemonCMD($board_id='',$DemonName)	// Démarre le Démon
	{	
		$DemonName = FilterDemon($DemonName);
		if ($DemonName == null) return false;
		if ($board_id=='')
		{
			Jlog( 'error', ' $board_id n est pas fourni !.');
			return false;
		}
		$jeedouinoPATH = realpath(dirname(__FILE__));
		$filename=$jeedouinoPATH.'/jeedouino'.$DemonName.'_'.$board_id.'.py';
		if (file_exists($filename)) unlink($filename);

		$DemonFileName=$jeedouinoPATH.'/jeedouino'.$DemonName.'.py';
		if (!copy($DemonFileName, $filename)) 
		{
			Jlog( 'error', ' Impossible de créer le fichier pour le démon ( '.$filename.' ).');
			$filename=$DemonFileName;					
		}
		$prmFilename=$jeedouinoPATH.'/jeedouino'.$DemonName.'_'.$board_id.'.prm';
		if (!file_exists($prmFilename))
		{
			 Jlog( 'error', 'Le fichier .prm du démon '.$DemonName.' (eqID : '.$board_id.') est introuvable ! :'.$prmFilename . '. Re-sauvez l\'équipement dans Jeedom.');
			 return false;
		}
		$prmFile = file_get_contents($prmFilename);
		
		StopDemonCMD($board_id,$DemonName); // Stoppe le(s) processus du Démon local

		$cmd = "sudo /usr/bin/nice -n 19 /usr/bin/python ".$filename.' '.$prmFile;
		Jlog( 'debug', 'Cmd Appel démon : '.$cmd);
		$reponse = exec($cmd . ' >> Jeedouino'.$DemonName.'.log 2>&1 &');
		
		if ((strpos(strtolower($reponse), 'error') !== false) or (strpos(strtolower($reponse), 'traceback') !== false))
		{
			Jlog( 'error', 'Le démon ' . $DemonName . ' ne démarre pas - Réponse :' . $reponse);
			return false;
		}
		else  Jlog('debug', 'Le démon ' . $DemonName . ' devrait démarrer  - ' . $reponse);
		
		$logFileName = 'Jeedouino'.$DemonName.'.log';
		$maxLineLog = 500;
		shell_exec('sudo chmod 777 ' . $logFileName . ' ;echo "$(tail -n ' . $maxLineLog . ' ' . $logFileName . ')" > ' . $logFileName);
		return true;
	}
	function StopDemonCMD($board_id='',$DemonName)	// Stoppe le(s) processus du Démon local
	{
		$DemonName = FilterDemon($DemonName);
		if ($DemonName == null) return false;		
		if ($board_id=='') $DemonFileName='jeedouino'.$DemonName.'.py';
		else $DemonFileName='jeedouino'.$DemonName.'_'.$board_id.'.py';
		// Si  il y a toujours des processus en cours, on les tues
		exec("sudo  /usr/bin/pgrep --full ".$DemonFileName, $processus);
		$done=false;
		foreach ($processus as $process)
		{
			Jlog( 'debug','KILL process '.$process);
			exec('sudo /bin/kill -9 ' . $process . ' >> Jeedouino'.$DemonName.'.log 2>&1 &');
			$done=true;
			usleep(500000); //0.5 secondes
		}		
		//sleep(5);
		if ($done) 
		{
			Jlog( 'debug', 'StopDemonCMD - Arrêt forcé du démon '.$DemonName.' sur  '.GetJeedouinoIP().' - '.$DemonFileName.' : Kill process : '.json_encode($processus));
		}
		
		$logFileName = 'Jeedouino'.$DemonName.'.log';
		$maxLineLog = 500;
		shell_exec('sudo chmod 777 ' . $logFileName . ' ;echo "$(tail -n ' . $maxLineLog . ' ' . $logFileName . ')" > ' . $logFileName);		
		return true;
	}
	function StatusDemonCMD($board_id='',$DemonName)	// Processus du Démon en marche ??? (si ping ne réponds pas)
	{
		$DemonName = FilterDemon($DemonName);
		if ($DemonName == null) return false;			
		if ($board_id == '') $DemonFileName = 'jeedouino' . $DemonName . '.py';
		else $DemonFileName = 'jeedouino' . $DemonName . '_' . $board_id . '.py';		
		exec("/usr/bin/pgrep --full " . $DemonFileName, $processus);
		Jlog( 'debug', 'StatusDemonCMD - L\'état du démon ' . $DemonName . ' est ' . (isset($processus[1])?' Actif ':'Inactif') . ' sur ' . GetJeedouinoIP() . ' - ' . $DemonFileName . ' : process : ' . json_encode($processus));
		return isset($processus[1]);
	}
	function EraseDemonFileCMD($board_id='',$DemonName)	// Efface le fichier python généré pour le Démon
	{
		$DemonName = FilterDemon($DemonName);
		if ($DemonName == null) return false;			
		$jeedouinoPATH = realpath(dirname(__FILE__));
		if ($board_id!='') 
		{
			// python
			$DemonFileName=$jeedouinoPATH.'/jeedouino'.$DemonName.'_'.$board_id.'.py';			
			if (!file_exists($DemonFileName)) Jlog( 'error', 'Le fichier .py du démon '.$DemonName.' (eqID : '.$board_id.') est introuvable ! :'.$DemonFileName);
			else
			{
				unlink($DemonFileName);
				Jlog( 'debug', 'Le fichier .py du démon '.$DemonName.'  (eqID : '.$board_id.') est supprimé ! :');
			}
			
			// prm
			$DemonFileName=$jeedouinoPATH.'/jeedouino'.$DemonName.'_'.$board_id.'.prm';			
			if (!file_exists($DemonFileName)) Jlog( 'error', 'Le fichier .prm du démon '.$DemonName.' (eqID : '.$board_id.') est introuvable ! :'.$DemonFileName);
			else
			{
				unlink($DemonFileName);
				Jlog( 'debug', 'Le fichier .prm du démon '.$DemonName.'  (eqID : '.$board_id.') est supprimé ! :');
			}
			RemovePRM($board_id);
			// Logs
			EraseLogFileCMD($DemonName);
			return true;
		}
		else return false;
	} 
	function ReStartDemonCMD($board_id,$DemonName)	// Redémarre le Démon
	{
		$DemonName = FilterDemon($DemonName);
		if ($DemonName == null) return false;			
		if (StatusDemonCMD($board_id,$DemonName))
		{
			StopDemonCMD($board_id,$DemonName);
		}
		usleep(1500000); // 1.5 secondes  
		StartDemonCMD($board_id,$DemonName);
	return true;
	}
	function EraseLogFileCMD($DemonName)	// Efface le fichier Log généré pour le Démon / JeedouinoExt
	{	
		$DemonName = FilterDemon($DemonName);
		if ($DemonName == null) return false;		
		$jeedouinoPATH = realpath(dirname(__FILE__));

		$DemonFileName=$jeedouinoPATH.'/Jeedouino'.$DemonName.'.log';			
		if (file_exists($DemonFileName)) 
		{
			unlink($DemonFileName);
			$logFile = date("Y-m-d H:i:s") . ' [ Fichier Purge par l\'utilisateur. ] '."\r\n"; 
			file_put_contents($DemonFileName,$logFile);
			Jlog( 'debug', 'Le fichier de log : '.$DemonFileName.'  est purgé ! ');
			return true;
		}
		Jlog( 'error', 'Le fichier de log : '.$DemonFileName.' est introuvable ! ');
		return false;
	}
	function EraseLogFile($logFile)
	{	
		$FileName = realpath(dirname(__FILE__))  . '/' . $logFile;
		if (file_exists($FileName))
		{
			unlink($FileName);
			$logFile = date("Y-m-d H:i:s") . ' [ Fichier Purge par l\'utilisateur. ] ' . "\r\n"; 
			file_put_contents($FileName, $logFile);
			Jlog( 'debug', 'Le fichier de log : ' . $FileName . '  est purgé ! ');
			return true;
		}
		Jlog( 'error', 'Le fichier de log : ' . $FileName . ' est introuvable ! ');
		return false;
	} 
	?>