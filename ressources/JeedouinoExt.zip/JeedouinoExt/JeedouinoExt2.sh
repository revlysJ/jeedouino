##
# JeedouinoExt Install déportée sur RaspberryPi sans Jeedom
# v0.3 alpha
##

echo "================================="
echo "== JeedouinoExt v0.3 alpha"
echo "== Debut de l'installation ..."
echo "================================="

echo "== Copie des fichiers JeedouinoExt et mise en place des droits  ..."
echo "================================="
sudo chmod -R 775 /var/www/
sudo mkdir -p /var/www/html/JeedouinoExt
sudo cp -r /tmp/JeedouinoExt/*  /var/www/html/JeedouinoExt/
sudo chown -R www-data:www-data /var/www/html
sudo chmod -R 775 /var/www/html
sudo rm -Rf /tmp/JeedouinoExt*

echo "== Installation des dependances Python ..."
echo "================================="
# installation des dependances Python
sudo apt-get -y install build-essential python{,3}-pip python{,3}-setuptools python-serial python{,3}-dev python{,3}-openssl git
sudo pip3 install --upgrade setuptools pip
sudo pip install wheel
sudo pip3 install wheel
sudo pip3 uninstall serial
sudo pip3 install pyserial

echo "== Installation RPi.GPIO  ..."
echo "================================="
sudo pip3 install RPi.GPIO

echo "== Installation de la lib Adafruit_Python_DHT  ..."
echo "================================="
git clone https://github.com/adafruit/Adafruit_Python_DHT.git
cd Adafruit_Python_DHT
sudo python setup.py install
sudo python3 setup.py install
cd ..

echo "== Installation de la lib Adafruit_Python_BMP085/180  ..."
echo "================================="
git clone https://github.com/adafruit/Adafruit_Python_BMP.git
cd Adafruit_Python_BMP
sudo python setup.py install
sudo python3 setup.py install
cd ..

echo "== Installation de la lib ABElectronics_Python_Libraries  ..."
echo "================================="
git clone https://github.com/abelectronicsuk/ABElectronics_Python_Libraries.git
cd ABElectronics_Python_Libraries
sudo python setup.py install
sudo python3 setup.py install
cd ..

echo "== Installation de la lib danjperron/BitBangingDS18B20  ..."
echo "================================="
git clone https://github.com/danjperron/BitBangingDS18B20.git
cd BitBangingDS18B20/python
sudo python setup.py install
sudo python3 setup.py install
cd ../..

echo "== Installation de la lib Adafruit_Python_BME280  ..."
echo "================================="
pip3 install adafruit-circuitpython-lis3dh
sudo pip3 install adafruit-circuitpython-bme280
sudo pip3 install adafruit-circuitpython-bmp280

echo "== Installation de la lib Adafruit_Python_BME680  ..."
echo "================================="
sudo pip3 install adafruit-circuitpython-bme680

echo "================================="
echo "== Fin de l'installation ..."
echo "================================="