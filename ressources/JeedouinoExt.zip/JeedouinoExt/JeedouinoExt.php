<?php
/* This file is part of Jeedouino, plugin of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */

$this_file = "JeedouinoExt.php";
if (isset($_SERVER['REQUEST_URI']))	
{
	$this_url = $_SERVER['REQUEST_URI']; //__FILE__; 
}
else
{
	$this_url = $_SERVER['PHP_SELF']; //__FILE__; 
}

$this_url = str_replace($this_file ,'' , $this_url );
$p0 = strpos($this_url, '?');
if ($p0 !== false) $this_url = substr($this_url, 0 , $p0); // supprime les params après ? dans l'url reçue.
if (isset($_SERVER['SERVER_PORT']))	
{
	$this_port = $_SERVER['SERVER_PORT']; //__FILE__; 
}
else
{
	$this_port = 80;
}

include 'jeedouinoExt.inc.php';	
// POST_log();
// GET_log() ;

// Gestion $_POST[''] : SetJeedomCFG  SetPRM  $CallCmd
// from this Html Form
if (isset($_POST['SetCFG']))	
{
	if (isset($_POST['IP']) && isset($_POST['Port']))
	{
		if (!isset($_POST['Cpl'])) $cpl = '';
		else $cpl = $_POST['Cpl'];
		SetJeedomCFG($_POST['IP'] ,$_POST['Port'] , $cpl);
		header('location: '.$this_file);
	}
}
sleep(1);

$cfg = GetJeedomCFG();
Jlog( 'debug', 'GetJeedomCFG = '.$cfg);
if ($cfg !== false) 
{
	$_CFG = json_decode($cfg, true);
	$JeedomURL = '' . $_CFG['IP'] . ':' . $_CFG['Port'] . $_CFG['Cpl'] . '/';
}
else 
{
	$_CFG = array('IP' => '', 'Port' => '', 'Cpl' => '');
	$JeedomURL = '';
}

$UsbMapping = getUsbMapping();
if ($_CFG['IP'] != '') 
{
	$param = 'ip='.GetJeedouinoIP();
	$param .= '&port='.$this_port;
	$param .= '&path='.urlencode($this_url);
	$param .= '&usbMapping='.urlencode(json_encode($UsbMapping));
	//$reponse = CallbackExt($_CFG['IP'], $_CFG['Port'], $param);
	$url = 'http://'.$_CFG['IP']. ':'. $_CFG['Port']. $_CFG['Cpl']. '/plugins/jeedouino/core/php/CallbackExt.php?'. $param;
	$reponse = file_get_contents($url);
	Jlog( 'debug', 'Call '. $_CFG['IP']. ':'. $_CFG['Port']. ' - '. $reponse);
}

// From Jeedom
if (isset($_GET['SetJeedomCFG'])) 
{
	Jlog( 'debug', 'SetJeedomCFG = '.$_GET['SetJeedomCFG']);

	// from $prm = json_encode(array('IP' => $JeedomIP, 'Port' => $JeedomPort, 'Cpl' => $JeedomCPL));
	$params = json_decode($_GET['SetJeedomCFG'], true);
	if (isset($params['IP']) && isset($params['Port']) && isset($params['Cpl']))
	{
		SetJeedomCFG($params['IP'] ,$params['Port'] ,$params['Cpl']);
		echo 'OK';
		die();
	}
}
if (isset($_GET['SetPRM']))
{
	// from $prm = json_encode(array('board_id' => $arduino_id, 'DemonName' => $DemonName, 'prm' => $setprm));
	$params = json_decode($_GET['SetPRM'], true);
	if (isset($params['board_id']) && isset($params['DemonName']) && isset($params['prm']))
	{
		SetPRM($params['board_id'] ,$params['DemonName'] ,$params['prm']);
		echo 'OK';
		die();
	}
}	
	// Actions pour la gestion des démons / Jeedouino
 	if (isset($_GET['StartBoardDemonCMD']))
    {
		$params = json_decode($_GET['StartBoardDemonCMD'], true);
        if (StartDemonCMD($params['eqLogic'], $params['DemonType'])) echo 'OK';
		else echo 'NOK';
		die();
	}   
  	if (isset($_GET['ReStartBoardDemonCMD']))
    {
		$params = json_decode($_GET['ReStartBoardDemonCMD'], true);
        if (ReStartDemonCMD($params['eqLogic'], $params['DemonType'])) echo 'OK';
		else echo 'NOK';
		die();
	}   
 	if (isset($_GET['StopBoardDemonCMD']))
    {
		$params = json_decode($_GET['StopBoardDemonCMD'], true);
        if (StopDemonCMD($params['eqLogic'], $params['DemonType'])) echo 'OK';
		else echo 'NOK';
		die();
	}
 	if (isset($_GET['EraseBoardDemonFileCMD']))
    {
		$params = json_decode($_GET['EraseBoardDemonFileCMD'], true);
        if (EraseDemonFileCMD($params['eqLogic'], $params['DemonType'])) echo 'OK';
		else echo 'NOK';
		die();
	}	
	// Actions pour la gestion du démon piFace / Jeedouino
 	if (isset($_GET['StartPiFaceDemonCMD']))
    {
		$params = json_decode($_GET['StartPiFaceDemonCMD'], true);
        StartDemonCMD($params['eqLogic'],'PiFace');		 
		echo 'OK';
		die();
	}   
  	if (isset($_GET['ReStartPiFaceDemonCMD']))
    {
		$params = json_decode($_GET['ReStartPiFaceDemonCMD'], true);
        ReStartDemonCMD($params['eqLogic'],'PiFace');  
		echo 'OK';
		die();
	}   
 	if (isset($_GET['StopPiFaceDemonCMD']))
    {
		$params = json_decode($_GET['StopPiFaceDemonCMD'], true);
        StopDemonCMD($params['eqLogic'],'PiFace');  
		echo 'OK';
		die();
	}
 	if (isset($_GET['ErasePiFaceDemonFileCMD']))
    {
		$params = json_decode($_GET['ErasePiFaceDemonFileCMD'], true);
        EraseDemonFileCMD($params['eqLogic'],'PiFace');
		echo 'OK';
		die();
	}		
    // Actions pour la gestion du démon piGPIO / Jeedouino
 	if (isset($_GET['StartPiGpioDemonCMD']))
    {
		$params = json_decode($_GET['StartPiGpioDemonCMD'], true);
        StartDemonCMD($params['eqLogic'],'PiGpio');  
		echo 'OK';
		die();
	}   
  	if (isset($_GET['ReStartPiGpioDemonCMD']))
    {
		$params = json_decode($_GET['ReStartPiGpioDemonCMD'], true);
        ReStartDemonCMD($params['eqLogic'],'PiGpio');  
		echo 'OK';
		die();
	}   
 	if (isset($_GET['StopPiGpioDemonCMD']))
    {
		$params = json_decode($_GET['StopPiGpioDemonCMD'], true);
        StopDemonCMD($params['eqLogic'],'PiGpio'); 
		echo 'OK';
		die();
	}
 	if (isset($_GET['ErasePiGpioDemonFileCMD']))
    {
		$params = json_decode($_GET['ErasePiGpioDemonFileCMD'], true);
        EraseDemonFileCMD($params['eqLogic'],'PiGpio');
		echo 'OK';
		die();
	}	
    // Actions pour la gestion du démon PiPlus / Jeedouino
 	if (isset($_GET['StartPiPlusDemonCMD']))
    {
		$params = json_decode($_GET['StartPiPlusDemonCMD'], true);
        StartDemonCMD($params['eqLogic'],'PiPlus');  
		echo 'OK';
		die();
	}   
  	if (isset($_GET['ReStartPiPlusDemonCMD']))
    {
		$params = json_decode($_GET['ReStartPiPlusDemonCMD'], true);
        ReStartDemonCMD($params['eqLogic'],'PiPlus');	 
		echo 'OK';
		die();
	}   
 	if (isset($_GET['StopPiPlusDemonCMD']))
    {
		$params = json_decode($_GET['StopPiPlusDemonCMD'], true);
        StopDemonCMD($params['eqLogic'],'PiPlus');  
		echo 'OK';
		die();
	}
 	if (isset($_GET['ErasePiPlusDemonFileCMD']))
    {
		$params = json_decode($_GET['ErasePiPlusDemonFileCMD'], true);
        EraseDemonFileCMD($params['eqLogic'],'PiPlus');
		echo 'OK';
		die();
	}
    // Actions pour la gestion du démon ArduinoUsb / Jeedouino
 	if (isset($_GET['StartArduinoUsbDemonCMD']))
    {
		$params = json_decode($_GET['StartArduinoUsbDemonCMD'], true);
        StartDemonCMD($params['eqLogic'],'USB');  
		echo 'OK';
		die();
	}   
  	if (isset($_GET['ReStartArduinoUsbDemonCMD']))
    {
		$params = json_decode($_GET['ReStartArduinoUsbDemonCMD'], true);
        ReStartDemonCMD($params['eqLogic'],'USB');  
		echo 'OK';
		die();
	}   
 	if (isset($_GET['StopArduinoUsbDemonCMD']))
    {
		$params = json_decode($_GET['StopArduinoUsbDemonCMD'], true);
        StopDemonCMD($params['eqLogic'],'USB'); 
		echo 'OK';
		die();
	}
 	if (isset($_GET['EraseArduinoUsbDemonFileCMD']))
    {
		$params = json_decode($_GET['EraseArduinoUsbDemonFileCMD'], true);
        EraseDemonFileCMD($params['eqLogic'],'USB');
		echo 'OK';
		die();
	}


// html stuff
?>
<html lang="fr">
	<head>
	<meta charset="utf-8">
	<title>Jeedouino - Jeedom</title>
	<meta http-equiv = "Refresh" content="60">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<link rel="stylesheet" href="/JeedouinoExt/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="/JeedouinoExt/jquery.ui/jquery-ui.css">
	<link rel="stylesheet" href="/JeedouinoExt/font-awesome/css/font-awesome.min.css">
	<script src="/JeedouinoExt/jquery/jquery.min.js"></script>
	<script src="/JeedouinoExt/jquery.ui/jquery-ui.min.js"></script>	
	</head>
	<body>
	<div class="col-lg-12 alert alert-success">
	<h1>JeedouinoExt v0.96 Alpha (c) Revlys</h1>
	</div>
	<div class="col-lg-12 alert alert-info">
	<span>Pensez à réactualiser cette page (F5) pour voir les changements éventuels, ou patientez 1+ min pour le refresh auto.</span>
	</div>
	<div style="display: none; width: 100%;" id="div_alert"></div>
<?php // Bloc 1 ?>
	<div class="col-sm-5">
	<form class="form-horizontal" method="POST">
    <fieldset style=" border: 1px solid #cccccc;"> 	
	<label class="alert alert-danger">Configuration du Jeedom Maître</label>    
		<div class="form-group alert alert-danger" style="margin: 10px; border: 1px solid;">
			  
				
			<div class="ipsource">
			   <div class="form-group">
					<label class="col-sm-2 control-label">IP</label>
					<div class="col-sm-5">
						<input type="text" class="configKey form-control"  name="IP" placeholder="ex : 192.168.0.55" value="<?php echo $_CFG['IP']; ?>"/>
					</div>
				</div> 	
				<div class="form-group" >					
					<label class="col-sm-2 control-label">Port</label>
					<div class="col-sm-5">
						<input type="text" class="configKey form-control"  name="Port" placeholder="ex : 80" value="<?php echo $_CFG['Port']; ?>"/>
					</div>       
				</div> 	
				<div class="form-group" >					
					<label class="col-sm-2 control-label">Complément</label>
					<div class="col-sm-5">
						<input type="text" class="configKey form-control"  name="Cpl" placeholder="ex : /jeedom" value="<?php echo $_CFG['Cpl']; ?>"/>
					</div>    					
				</div>
			</div>	
		</div>
		<input  type="submit" class="btn btn-success pull-right" name="SetCFG">
    </fieldset> 
	</form>
	

<?php // Bloc 3 ?>	
	
	<form class="form-horizontal">
    <fieldset style=" border: 1px solid #cccccc;"> 	
		<label class="alert alert-info">Dépendances pour les démons de Jeedouino</label>    
<span id="span_plugin_doc" class="pull-right"><a class="btn btn-danger btn-xs" target="_blank" href="https://www.jeedom.fr/doc/documentation/plugins/jeedouino/fr_FR/jeedouino.html"><i class="fa fa-book"></i> Documentation</a></span>
		<div class="form-group alert alert-info" style="margin: 10px; border: 1px solid;">
			<div class="form-group" >
					<label class="col-lg-5 control-label">RPi.GPIO Installation</label>
					<div class="col-lg-5">
							<a class="btn btn-info bt_installGPIO" ><i class="fa fa-play"></i> sudo install RPi.GPIO</a>
					</div>            
			</div> 
			<div class="form-group" >
					<label class="col-lg-5 control-label">PiFace Digitalio Installation</label>
					<div class="col-lg-5">
							<a class="btn btn-info bt_installPIFACE" ><i class="fa fa-play"></i> sudo install python-pifacedigitalio</a>
					</div>            
			</div>      
			<div class="form-group" >
					<label class="col-lg-5 control-label">IO.PiPlus / MCP23017 smbus Installation</label>
					<div class="col-lg-5">
							<a class="btn btn-info bt_installPiPlus" ><i class="fa fa-play"></i> sudo install python-smbus</a>
					</div>            
			</div> 	
		</div> 	
    </fieldset>
	</form>
	</div> 
<?php // Bloc 2 ?>	
	<div class="col-sm-5">
	<form class="form-horizontal">
    <fieldset style=" border: 1px solid #cccccc;"> 	
		<label class="alert alert-warning">Configuration de ce Système</label>    
		<span id="span_phpinfo" class="pull-right"><a class="btn btn-info btn-xs" target="_blank" href="phpinfo.php"><i class="fa fa-book"></i> PhpInfo();</a></span>
		
		<div class="form-group alert alert-warning" style="margin: 10px; border: 1px solid;">
			<div class="form-group" >
					<label class="col-lg-5 control-label">MàJ Système</label>
					<div class="col-lg-5">
							<a class="btn btn-info bt_installUpdate" ><i class="fa fa-play"></i> sudo apt-get update</a>
					</div>            
			</div> 	
			<div class="form-group" >
					<label class="col-lg-5 control-label">Install Python Serial / DHT</label>
					<div class="col-lg-5">
							<a class="btn btn-info bt_installPython" ><i class="fa fa-play"></i> sudo /bin/bash Jeedouino.sh</a>
					</div>            
			</div> 				
			<div class="form-group" >
					<label class="col-lg-5 control-label">Redémarrer le système</label>
					<div class="col-lg-5">
							<a class="btn btn-warning bt_installReboot" ><i class="fa fa-play"></i> sudo reboot</a>
					</div>            
			</div> 	
			<div class="form-group" >
					<label class="col-lg-5 control-label">Eteindre le système</label>
					<div class="col-lg-5">
							<a class="btn btn-danger bt_installShutdown" ><i class="fa fa-play"></i> sudo shutdown</a>
					</div>            
			</div> 
			<div class="form-group" >
					<label class="col-lg-5 control-label">IP : PORT / PATH </label>
					<div class="col-lg-5">
							<a class="btn btn-info " ><i class="fa fa-sitemap"></i> <?php echo GetJeedouinoIP() . ' : ' . $this_port . $this_url;  ?></a>
					</div>            
			</div> 				
			<div class="form-group">
				<label class="col-lg-5 control-label">Port USB disponibles</label>
				<div class="col-lg-5">
					<select class="form-control" >
							<?php
							foreach ($UsbMapping as $name => $value) 
							{
								echo '<option value="' . $name . '">' . $name . ' (' . $value . ')</option>';
							}
							?>
					</select>
				</div>
			</div>	
			<div class="form-group" >
					<label class="col-lg-5 control-label">Logs JeedouinoExt</label>
					<div class="col-lg-5">
						<a class="btn btn-info" target="_blank" href="JeedouinoExt.log"><i class="fa fa-pencil-square-o"></i></i> JeedouinoExt</a>
						<?php
							echo '<a class="btn btn-danger bt_DeleteExtLog" boardID="0"><i class="fa fa-eraser"></i></a>';
						?>  								
					</div>             
			</div> 			
		</div>
    </fieldset> 
	</form>
	</div> 	

<?php // Bloc 4 ?>
<div class="col-sm-5">
	<form class="form-horizontal">
    <fieldset style=" border: 1px solid #cccccc;"> 	
		<label class="alert alert-warning">Màj des fichiers de JeedouinoExt (A faire après une màj du plugin dans Jeedom)</label>    
		<div class="form-group alert alert-warning" style="margin: 10px; border: 1px solid;">
			<div class="form-group" >
					<label class="col-lg-5 control-label">MàJ fichiers</label>
					<div class="col-lg-5">
							<a class="btn btn-warning bt_FilesUpdate" ><i class="fa fa-play"></i> sudo /bin/bash JeedouinoExt.maj</a>
					</div>            
			</div> 
		</div> 
    </fieldset> 
	</form>		
</div>
<?php // Bloc 5 
	$jeedouinoPATH = realpath(dirname(__FILE__));
	$filename = $jeedouinoPATH.'/jeedouinoPrm.prm';	
	$status = file_exists($filename);
	$ctext = $status ? 'success' : 'danger';
?>
	<div class="col-sm-10">
	<form class="form-horizontal">
    <fieldset style=" border: 1px solid #cccccc;"> 	
		<label class="alert alert-<?php echo $ctext; ?>">Gestion des équipements avec démons sur ce RPI</label>
		<div class="form-group alert alert-<?php echo $ctext; ?>" style="margin: 10px; border: 1px solid;">
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>Equipement</th>				
						<th>Statut</th>
						<th>(Re)Démarrer</th>
						<th>Arrêter</th>
						<th>Type</th>
						<th>Port</th>
						<th>Logs</th>
					</tr>
				</thead>
				<tbody>
				<?php
					if ($status) 
					{
						$file = file_get_contents($filename);
						$prm = json_decode($file, true);
						foreach ($prm as $board_id => $board_prm)
						{
							$DemonName = $board_prm['DemonName'];
							$port = $board_prm['Port'];
							$StatusDemon = StatusDemonCMD($board_id, $DemonName);
							?>
							<tr>
								<td>
									<?php 
										echo '<div class="col-lg-7"><a class="btn btn-default " target="_blank" href="http://'.$JeedomURL.'index.php?&v=d&p=jeedouino&m=jeedouino&id='.$board_id.'"><i class="fa fa-sitemap"></i> EqID  '.$board_id.'</a> '; 
										echo '<a class="btn btn-danger bt_Delete'.$DemonName.'Demon" boardID="'. $board_id.'"><i class="fa fa-eraser"></i> Eff</a></div>';
									?>
								</td>									
								<td class="deamonState">
									<?php
										if ($StatusDemon) echo '<span class="label label-success" style="font-size : 1em;" >OK</span>';
										else echo '<span class="label label-danger tooltips" style="font-size : 1em;" >NOK</span>';
									?>
								</td>
								<td>
									<?php
										if ($StatusDemon) echo '<a class="btn btn-success bt_ReStart'.$DemonName.'Demon" boardID="'. $board_id.'"><i class="fa fa-play"></i></a>';
										else echo '<a class="btn btn-success bt_Start'.$DemonName.'Demon" boardID="'. $board_id.'"><i class="fa fa-play"></i></a>';
									?>  
								</td>
								<td>
									<?php
										if ($StatusDemon) echo '<a class="btn btn-danger bt_Stop'.$DemonName.'Demon" boardID="'. $board_id.'"><i class="fa fa-stop"></i></a>';
									?>  
								</td>
								<td><?php echo $DemonName; ?></td>
								<td><?php echo $port; ?></td>
								<td>
									<a class="btn btn-default" target="_blank" href="Jeedouino<?php echo $DemonName; ?>.log"><i class="fa fa-pencil-square-o"></i></i></a>
									<?php
										echo '<a class="btn btn-danger bt_Delete'.$DemonName.'Log" boardID="'. $board_id.'"><i class="fa fa-eraser"></i></a>';
									?>  									
								</td>
						
							</tr>
							<?php
						}
					}
					else
					{
						echo '<tr><td colspan="7"><span class="label label-danger tooltips" style="font-size : 1em;" >Veuillez re-sauver vos équipements JeedouinoExt dans Jeedom. Merci.</span></td></tr>';
					}
					?>
				</tbody>
			</table>	
		</div>
    </fieldset>
	</form>
	</div> 	

<script src="JeedouinoExt.js"></script>	
<?php
echo '<script>';
gen_button("installShutdown", 'Le système est en cours d arrêt.');
gen_button("installReboot", 'Le système est en cours de redémarrage.'); 
gen_button("installUpdate", 'Le système est en cours de mise à jour.');
gen_button("FilesUpdate", 'Les fichiers JeedouinoExt sont en cours de mise à jour.');
gen_button("installPython", 'Les librairies Python Serial / DHT sont en cours d installation.');
gen_button("installPiPlus", 'Les dépendances IO.PiPlus sont en cours d installation.');
gen_button("installGPIO", 'Les dépendances RPI.GPIO sont en cours d installation.');
gen_button("installPIFACE", 'Les dépendances PIFACEDIGITALIO sont en cours d installation.');

gen_button("StartPiFaceDemon", 'Le démon va être démarré.');
gen_button("ReStartPiFaceDemon", 'Le démon va être (re)démarré.');
gen_button("StopPiFaceDemon", 'Le démon va être arreté.');
gen_button("DeletePiFaceDemon", 'Le démon va être éffacé.');

gen_button("StartPiGpioDemon", 'Le démon va être démarré.');
gen_button("ReStartPiGpioDemon", 'Le démon va être (re)démarré.');
gen_button("StopPiGpioDemon", 'Le démon va être arreté.');
gen_button("DeletePiGpioDemon", 'Le démon va être éffacé.');

gen_button("StartUSBDemon", 'Le démon va être démarré.');
gen_button("ReStartUSBDemon", 'Le démon va être (re)démarré.');
gen_button("StopUSBDemon", 'Le démon va être arreté.');
gen_button("DeleteUSBDemon", 'Le démon va être éffacé.');

gen_button("StartPiPlusDemon", 'Le démon va être démarré.');
gen_button("ReStartPiPlusDemon", 'Le démon va être (re)démarré.');
gen_button("StopPiPlusDemon", 'Le démon va être arreté.');
gen_button("DeletePiPlusDemon", 'Le démon va être éffacé.');

gen_button("DeleteExtLog", 'Purge du fichier de log JeedouinoExt.log en cours.');
gen_button("DeletePiPlusLog", 'Purge du fichier de log JeedouinoPiPlus.log en cours.');
gen_button("DeletePiGpioLog", 'Purge du fichier de log JeedouinoPiGpio.log en cours.');
gen_button("DeleteUSBLog", 'Purge du fichier de log JeedouinoUSB.log en cours.');
gen_button("DeletePiFaceLog", 'Purge du fichier de log JeedouinoPiFace.log en cours.');

echo '</script>';
?>

</body>
</html>
